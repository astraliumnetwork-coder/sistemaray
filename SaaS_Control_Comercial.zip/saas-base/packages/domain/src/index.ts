import { z } from 'zod';
export const channelSchema = z.enum(['retail', 'orders']);
export type Channel = z.infer<typeof channelSchema>;
export const paymentSchema = z.enum(['cash', 'yape', 'plin', 'transfer']);
export const paymentLabels = {
  cash: 'Efectivo',
  yape: 'Yape',
  plin: 'Plin',
  transfer: 'Transferencia',
};
export const channelLabels = { retail: 'Menudeo', orders: 'Pedidos' };
export const centsSchema = z.number().int().min(0).max(100_000_000);
export const integerSchema = z.number().int().safe();
export function parseMoney(value: string): number {
  if (!/^\d{1,7}(\.\d{1,2})?$/.test(value.trim()))
    throw new Error('Ingresa un monto positivo con máximo 2 decimales.');
  const [whole = '0', fraction = ''] = value.trim().split('.');
  return centsSchema.parse(Number(whole) * 100 + Number(fraction.padEnd(2, '0')));
}
export function money(cents: number): string {
  return new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN' }).format(cents / 100);
}
export function calculateLine(quantity: number, priceCents: number, costCents: number) {
  z.number().int().min(1).max(100_000).parse(quantity);
  centsSchema.parse(priceCents);
  centsSchema.parse(costCents);
  const salesCents = quantity * priceCents;
  const costTotalCents = quantity * costCents;
  return { salesCents, costTotalCents, grossCents: salesCents - costTotalCents };
}
export function localDate(now = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Lima',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const get = (type: string) => parts.find((p) => p.type === type)?.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}
export const dateSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine((value) => {
    const date = new Date(`${value}T12:00:00Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }, 'Fecha inválida');
export const productInput = z.object({
  sku: z.string().trim().min(1).max(40),
  name: z.string().trim().min(2).max(120),
  priceCents: centsSchema,
  costCents: centsSchema,
  retailStock: z.number().int().min(0).max(1_000_000),
  ordersStock: z.number().int().min(0).max(1_000_000),
});
export const productSchema = productInput.extend({ id: z.string().uuid(), active: z.boolean() });
export type Product = z.infer<typeof productSchema>;
export const itemInput = z.object({
  productId: z.string().uuid(),
  quantity: z.number().int().min(1).max(100_000),
  priceCents: centsSchema,
  costCents: centsSchema,
});
export const saleInput = z
  .object({
    channel: channelSchema,
    payment: paymentSchema,
    customer: z.string().trim().max(120).default(''),
    scheduledFor: dateSchema.nullable().default(null),
    items: z.array(itemInput).min(1).max(100),
  })
  .refine(
    (v) => new Set(v.items.map((i) => i.productId)).size === v.items.length,
    'Combina los productos repetidos en una sola línea',
  )
  .refine((v) => v.channel !== 'orders' || v.customer.length > 0, 'Indica el cliente del pedido');
export type SaleInput = z.infer<typeof saleInput>;
export const saleSchema = z.object({
  orderCode: z.string().nullable().optional(),
  id: z.string().uuid(),
  channel: channelSchema,
  payment: paymentSchema,
  customer: z.string(),
  scheduledFor: z.string().nullable(),
  createdAt: z.string(),
  recognizedAt: z.string().nullable(),
  status: z.enum(['pending', 'posted', 'cancelled']),
  salesCents: integerSchema,
  costTotalCents: integerSchema,
  grossCents: integerSchema,
});
export type Sale = z.infer<typeof saleSchema>;
export const itemSchema = itemInput.extend({
  name: z.string(),
  salesCents: integerSchema,
  costTotalCents: integerSchema,
  grossCents: integerSchema,
});
export const expenseInput = z.object({
  description: z.string().trim().min(2).max(160),
  amountCents: centsSchema.refine((v) => v > 0),
  spentOn: dateSchema,
  channel: channelSchema,
});
export const expenseSchema = expenseInput.extend({ id: z.string().uuid() });
export type Expense = z.infer<typeof expenseSchema>;
export function pageSchema<T extends z.ZodTypeAny>(schema: T) {
  return z.object({
    items: z.array(schema),
    total: z.number().int().nonnegative(),
    page: z.number().int().positive(),
    pageSize: z.number().int().positive(),
  });
}
export const sessionSchema = z.object({
  userId: z.string().uuid(),
  tenantId: z.string().uuid(),
  email: z.string().min(1),
  organizationName: z.string(),
});
export type Session = z.infer<typeof sessionSchema>;
export const credentialsSchema = z.object({
  email: z
    .string()
    .trim()
    .email()
    .max(254)
    .transform((v) => v.toLowerCase()),
  password: z.string().min(1, 'Escribe tu contraseña.').max(128),
});
export const registrationSchema = credentialsSchema.extend({
  password: z.string().min(12).max(128),
  organizationName: z.string().trim().min(2).max(80),
});
export const settingsSchema = z.object({
  organizationName: z.string().trim().min(2, 'Escribe al menos 2 caracteres.').max(80),
  currency: z.literal('PEN'),
  timezone: z.literal('America/Lima'),
});
export type WorkspaceSettings = z.infer<typeof settingsSchema>;
export const reportSchema = z.object({
  from: dateSchema,
  to: dateSchema,
  salesCents: integerSchema,
  costTotalCents: integerSchema,
  grossCents: integerSchema,
  expensesCents: integerSchema,
  netCents: integerSchema,
  transactions: integerSchema,
  byPayment: z.array(z.object({ payment: paymentSchema, salesCents: integerSchema })),
  daily: z.array(
    z.object({
      date: dateSchema,
      salesCents: integerSchema,
      costTotalCents: integerSchema,
      grossCents: integerSchema,
      expensesCents: integerSchema,
      netCents: integerSchema,
    }),
  ),
});
export type Report = z.infer<typeof reportSchema>;
