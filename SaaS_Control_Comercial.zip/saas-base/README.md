# Control Comercial · 0.3.0

SaaS de ventas, inventario y resultados. Frontend React + TypeScript + Vite conectado directamente a Supabase Auth y Postgres. La API Express y las conexiones PostgreSQL privadas ya no forman parte del arranque.

## Iniciar

Requisitos: Node.js 22.12 o superior y el proyecto Supabase configurado en `.env.example`.

```powershell
npm install
npm run dev
```

El ZIP incluye `.env` con la URL y la clave publicable del proyecto Supabase. Si falta, en PowerShell ejecuta `Copy-Item .env.example .env`. Las variables deben usar el prefijo `VITE_`, porque el cliente está hecho con Vite.

Accede con la cuenta existente **admin@sistema.com** y la contraseña configurada. No necesitas crear otra empresa ni ejecutar `setup:admin` nuevamente: los productos están en Supabase y se comparten entre equipos al entrar con la misma cuenta.

Para esta actualización, ejecuta **`supabase/order_codes.sql`** en Supabase → SQL Editor si todavía no aplicaste los códigos de pedidos. Es reejecutable. No ejecutes el esquema completo sobre tu base existente. Los filtros nuevos de inventario no requieren migración.

El logo original no está incluido en esta entrega: copia tu archivo a `public/logo.png` desde el otro equipo.

`.env` solo contiene `VITE_APP_NAME`, `VITE_SUPABASE_URL` y `VITE_SUPABASE_PUBLISHABLE_KEY`. La clave publicable está diseñada para el cliente web; RLS protege las tablas. No agregues una `service_role` al frontend.

## Funciones

- Login con Supabase Auth y cuenta vinculada a la empresa existente.
- Tenant derivado de `auth.uid()` en políticas RLS; el cliente nunca decide su tenant como autorización.
- Catálogo paginado, edición y existencias separadas para menudeo y pedidos.
- Ventas, entregas de pedidos, ajustes de stock y gastos atómicos mediante funciones SQL.
- Claves de idempotencia en mutaciones con efecto financiero o de inventario.
- Reportes diarios y por rango agrupados en PostgreSQL, en PEN y zona horaria America/Lima.

## Estructura

| Ruta                     | Responsabilidad                                                  |
| ------------------------ | ---------------------------------------------------------------- |
| `src/features`           | Pantallas, hooks y repositorios por módulo                       |
| `src/shared/supabase`    | Cliente Supabase y normalización de errores                      |
| `packages/domain`        | Esquemas, tipos, dinero y fechas compartidos                     |
| `supabase/schema.sql`    | Tablas, índices, RLS, trigger de alta y operaciones SQL          |
| `tests`                  | Reglas de dominio y pruebas del esquema/transacciones con PGlite |
| `docs/PROJECT_MEMORY.md` | Decisiones vigentes y punto de continuación                      |

Las vistas usan React Query. Las consultas llevan el signal de cancelación; la caché se segmenta por tenant y se limpia al cerrar sesión. Las lecturas se paginan en Supabase. Las operaciones que modifican varias tablas usan funciones SQL para que stock, auditoría y documentos se confirmen juntos o se reviertan juntos.

## Validar

```bash
npm run check
npm run build
```

El proyecto no requiere Docker, PostgreSQL local, `DATABASE_URL`, certificados ni servidor API para desarrollo. El esquema SQL se instala desde el editor de Supabase; después, solo se actualiza cuando se agregan cambios de base de datos.

## Reglas operativas

- Importes en céntimos enteros; ventas guardan el nombre, costo y precio utilizados.
- Un pedido pendiente no reserva stock ni cuenta como ingreso. Entregar valida y descuenta stock en una sola transacción.
- El resultado operativo simplificado es venta menos costo de mercadería y gastos registrados; no es un estado contable certificado.
- El proyecto no carga las cifras del Excel histórico. El archivo original no está disponible y el MD contiene una discrepancia en la utilidad declarada.

## Productos y códigos internos

Ejecuta una vez **`supabase/product_codes.sql`** en SQL Editor para una base existente. Convierte códigos `EXCEL-*` a `PRD-000001` sin modificar identificadores, stock ni ventas vinculadas. Nuevos productos reciben código automáticamente. El esquema completo se usa solo en bases nuevas.

Alta, edición y ajuste de stock se abren en modales. La tabla muestra precio, costo, utilidad/margen, existencias por canal. La carga del catálogo Excel ya fue utilizada y se retiró de la interfaz.

La auditoría del archivo original sigue en `docs/excel/LEEME.md`. Las ventas históricas no se importaron automáticamente.

## Inventario y edición

Filtros de nombre/código, existencias de menudeo o pedidos, orden por nombre/código/precio y 10/25/50 artículos por página. Se aplican en Supabase antes de paginar.

Al crear o editar, el listado muestra el producto guardado por su ID, aunque cambie de nombre o no cumpla los filtros anteriores. Pulsa «Ver todo el inventario» para regresar. Cancelar no modifica filtros ni página.

Para trabajar desde otro equipo, extrae el ZIP en una carpeta nueva, ejecuta `npm ci` y `npm run dev`. Incluye configuración publicable de Supabase, código, pruebas y migraciones; no incluye dependencias instaladas. Para Vercel usa las mismas variables VITE_ y conserva `vercel.json`.
