-- Ejecutar una vez desde SQL Editor antes de desplegar esta versión.
-- Reejecutable: conserva códigos, IDs, importes y stock.
begin;
lock table public.sales in share row exclusive mode;
alter table public.sales add column if not exists order_code text;
create sequence if not exists public.order_internal_code_seq;
revoke all on sequence public.order_internal_code_seq from public, anon, authenticated;
create or replace function public.assign_order_internal_code()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_number text;
begin
  if tg_op = 'UPDATE' and old.order_code is not null then
    if new.order_code is distinct from old.order_code then
      raise exception 'El código de pedido no se puede modificar.';
    end if;
    return new;
  end if;
  if new.channel = 'orders' then
    v_number := nextval('public.order_internal_code_seq'::regclass)::text;
    new.order_code := 'PED-' || lpad(v_number, greatest(6, length(v_number)), '0');
  else
    new.order_code := null;
  end if;
  return new;
end;
$$;
revoke all on function public.assign_order_internal_code() from public, anon, authenticated;
drop trigger if exists assign_order_internal_code on public.sales;
create trigger assign_order_internal_code before insert or update of order_code on public.sales
for each row execute function public.assign_order_internal_code();
do $$
declare v_id uuid;
begin
  for v_id in select id from public.sales where channel = 'orders' and order_code is null order by created_at, id loop
    update public.sales set order_code = null where id = v_id;
  end loop;
end;
$$;
create unique index if not exists sales_order_code_unique on public.sales(order_code) where order_code is not null;
do $$ begin
  if not exists(select 1 from pg_constraint where conrelid='public.sales'::regclass and conname='sales_order_code_valid') then
    alter table public.sales add constraint sales_order_code_valid check (
      (channel='orders' and order_code is not null and order_code ~ '^PED-[0-9]{6,}$') or
      (channel='retail' and order_code is null)
    );
  end if;
end $$;

create or replace function public.sale_detail(p_sale_id uuid)
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  with selected_sale as (
    select s.* from public.sales s where s.id = p_sale_id and s.tenant_id = public.current_tenant_id()
  ), line_rows as (
    select i.*, (i.quantity::bigint * i.price_cents) as sales_cents,
           (i.quantity::bigint * i.cost_cents) as cost_total_cents
    from public.sale_items i join selected_sale s on s.tenant_id = i.tenant_id and s.id = i.sale_id
  ), totals as (
    select coalesce(sum(sales_cents), 0) sales_cents, coalesce(sum(cost_total_cents), 0) cost_total_cents from line_rows
  )
  select case when s.id is null then null else jsonb_build_object(
    'sale', jsonb_build_object(
      'id', s.id, 'orderCode', s.order_code, 'channel', s.channel, 'payment', s.payment, 'customer', s.customer,
      'scheduledFor', s.scheduled_for, 'createdAt', s.created_at, 'recognizedAt', s.recognized_at,
      'status', s.status, 'salesCents', t.sales_cents, 'costTotalCents', t.cost_total_cents,
      'grossCents', t.sales_cents - t.cost_total_cents
    ),
    'items', coalesce((select jsonb_agg(jsonb_build_object(
      'productId', l.product_id, 'name', l.product_name, 'quantity', l.quantity,
      'priceCents', l.price_cents, 'costCents', l.cost_cents, 'salesCents', l.sales_cents,
      'costTotalCents', l.cost_total_cents, 'grossCents', l.sales_cents - l.cost_total_cents
    ) order by l.product_name) from line_rows l), '[]'::jsonb)
  ) end
  from selected_sale s cross join totals t
$$;

commit;
