import { QueryClient, QueryCache, MutationCache } from '@tanstack/react-query';
export function createQueryClient() {
  const client = new QueryClient({
    queryCache: new QueryCache(),
    mutationCache: new MutationCache(),
    defaultOptions: {
      queries: {
        staleTime: 60000,
        gcTime: 300000,
        refetchOnWindowFocus: false,
        retry: (count) => count < 1,
      },
      mutations: { retry: false },
    },
  });
  return client;
}
