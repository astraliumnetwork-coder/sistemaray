import { createBrowserRouter, Link } from 'react-router-dom';
import { ProtectedLayout } from './layout/ProtectedLayout';
import { PageState } from '@/shared/ui/PageState';
import { RouteError } from './layout/RouteError';
import { LoadingPage } from '@/shared/ui/LoadingPage';
export const router = createBrowserRouter([
  {
    path: '/acceso',
    lazy: () => import('@/features/auth/pages/AuthPage'),
  },
  {
    path: '/',
    Component: ProtectedLayout,
    ErrorBoundary: RouteError,
    HydrateFallback: LoadingPage,
    children: [
      { index: true, lazy: () => import('@/features/dashboard/pages/DashboardPage') },
      { path: 'productos', lazy: () => import('@/features/products/pages/ProductsPage') },
      { path: 'menudeo', lazy: () => import('@/features/retail/pages/RetailPage') },
      { path: 'pedidos', lazy: () => import('@/features/orders/pages/OrdersPage') },
      { path: 'gastos', lazy: () => import('@/features/finance/pages/ExpensesPage') },
      { path: 'reportes', lazy: () => import('@/features/finance/pages/ReportsPage') },
      { path: 'configuracion', lazy: () => import('@/features/settings/pages/SettingsPage') },
      {
        path: '*',
        element: (
          <PageState
            title="Página no encontrada"
            action={
              <Link className="button primary" to="/">
                Volver al inicio
              </Link>
            }
          >
            La dirección no corresponde a una página disponible.
          </PageState>
        ),
      },
    ],
  },
]);
