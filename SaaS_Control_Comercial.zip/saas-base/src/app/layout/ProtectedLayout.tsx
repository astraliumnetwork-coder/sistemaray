import { Navigate } from 'react-router-dom';
import { useSession } from '@/features/auth/hooks/useSession';
import { AppLayout } from './AppLayout';
import { PageState } from '@/shared/ui/PageState';
export function ProtectedLayout() {
  const session = useSession();
  if (session.isPending) return <PageState title="Verificando sesión…" />;
  if (session.isError)
    return (
      <PageState
        title="No se pudo verificar la sesión"
        action={
          <button className="button primary" onClick={() => void session.refetch()}>
            Reintentar
          </button>
        }
      >
        {session.error instanceof Error
          ? session.error.message
          : 'Revisa la conexión con Supabase.'}
      </PageState>
    );
  if (!session.data) return <Navigate to="/acceso" replace />;
  return <AppLayout />;
}
