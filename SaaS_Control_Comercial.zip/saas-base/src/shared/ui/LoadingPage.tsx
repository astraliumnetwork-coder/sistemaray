import { PageState } from './PageState';
export function LoadingPage() {
  return <PageState title="Cargando plataforma…" />;
}
