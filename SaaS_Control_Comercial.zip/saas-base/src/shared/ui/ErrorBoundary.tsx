import { Component } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
import { logger } from '@/shared/lib/logger';
export class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    logger.error(`render:${info.componentStack?.split('\n')[1]?.trim() ?? 'unknown'}`, error);
  }
  render() {
    if (this.state.failed)
      return (
        <main className="page-state" role="alert">
          <h1>No pudimos mostrar esta pantalla</h1>
          <p>Recarga la aplicación para volver a intentarlo.</p>
          <button className="button primary" onClick={() => window.location.reload()}>
            Recargar aplicación
          </button>
        </main>
      );
    return this.props.children;
  }
}
