// Un solo punto para conectar Sentry u otro proveedor. No registrar tokens ni cuerpos de peticiones.
export const logger = {
  error(event: string, error: unknown) {
    console.error(`[${event}]`, error instanceof Error ? error.message : 'Error no identificado');
  },
};
