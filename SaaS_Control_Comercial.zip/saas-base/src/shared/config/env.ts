import { z } from 'zod';

const schema = z.object({
  VITE_APP_NAME: z.string().trim().min(1).default('Control Comercial'),
  VITE_SUPABASE_URL: z.string().url(),
  VITE_SUPABASE_PUBLISHABLE_KEY: z.string().min(1),
});

const result = schema.safeParse(import.meta.env);

if (!result.success) {
  throw new Error(
    'Falta la configuración de Supabase. Crea .env en la raíz con VITE_SUPABASE_URL y VITE_SUPABASE_PUBLISHABLE_KEY. En Vite, las variables deben empezar con VITE_, no NEXT_PUBLIC_.',
  );
}

export const env = result.data;
