import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { Channel, SaleInput } from '@saas/domain';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { transactionsApi } from '../api/transactions.api';
export function useTransactions(channel: Channel, page: number) {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'sales', channel, page],
    queryFn: ({ signal }) => transactionsApi.list(channel, page, signal),
  });
}
export function useSaleDetail(id: string | null) {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'sale', id],
    enabled: !!id,
    queryFn: ({ signal }) => transactionsApi.detail(id!, signal),
  });
}
type Action =
  | { kind: 'create'; input: SaleInput; key: string }
  | { kind: 'complete'; id: string }
  | { kind: 'cancel'; id: string; reason: string };
export function useTransactionAction() {
  const client = useQueryClient();
  const tenant = useTenantId();
  return useMutation({
    mutationFn: async (v: Action) => {
      if (v.kind === 'create') return transactionsApi.create(v.input, v.key);
      if (v.kind === 'complete') return transactionsApi.complete(v.id);
      return transactionsApi.cancel(v.id, v.reason);
    },
    onSuccess: () => client.invalidateQueries({ queryKey: [tenant] }),
  });
}
