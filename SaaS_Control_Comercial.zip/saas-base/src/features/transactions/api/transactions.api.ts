import { z } from 'zod';
import { saleSchema, itemSchema, pageSchema } from '@saas/domain';
import { calculateLine } from '@saas/domain';
import type { Channel, SaleInput, Sale } from '@saas/domain';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';
const detailSchema = z.object({ sale: saleSchema, items: z.array(itemSchema) });

type SaleItemRow = {
  product_id: string;
  product_name: string;
  quantity: number;
  price_cents: number | string;
  cost_cents: number | string;
};
type SaleRow = {
  id: string;
  order_code: string | null;
  channel: Channel;
  payment: Sale['payment'];
  customer: string;
  scheduled_for: string | null;
  created_at: string;
  recognized_at: string | null;
  status: Sale['status'];
};

function mapDetail(row: SaleRow, saleItems: SaleItemRow[]) {
  const items = saleItems.map((item) => {
    const priceCents = Number(item.price_cents);
    const costCents = Number(item.cost_cents);
    const totals = calculateLine(item.quantity, priceCents, costCents);
    return {
      productId: item.product_id,
      name: item.product_name,
      quantity: item.quantity,
      priceCents,
      costCents,
      ...totals,
    };
  });
  const totals = items.reduce(
    (result, item) => ({
      salesCents: result.salesCents + item.salesCents,
      costTotalCents: result.costTotalCents + item.costTotalCents,
      grossCents: result.grossCents + item.grossCents,
    }),
    { salesCents: 0, costTotalCents: 0, grossCents: 0 },
  );
  return detailSchema.parse({
    sale: {
      id: row.id,
      orderCode: row.order_code,
      channel: row.channel,
      payment: row.payment,
      customer: row.customer,
      scheduledFor: row.scheduled_for,
      createdAt: row.created_at,
      recognizedAt: row.recognized_at,
      status: row.status,
      ...totals,
    },
    items,
  });
}

const saleSelect =
  'id,order_code,channel,payment,customer,scheduled_for,created_at,recognized_at,status';
export const transactionsApi = {
  async list(channel: Channel, page: number, signal: AbortSignal) {
    const pageSize = 25;
    const { data, error, count } = await supabase
      .from('sales')
      .select(saleSelect, { count: 'exact' })
      .eq('channel', channel)
      .order('created_at', { ascending: false })
      .order('id', { ascending: false })
      .range((page - 1) * pageSize, page * pageSize - 1)
      .abortSignal(signal);
    if (error) throwSupabaseError(error);
    const sales = (data ?? []) as unknown as SaleRow[];
    const saleIds = sales.map((sale) => sale.id);
    const linesResult = saleIds.length
      ? await supabase
          .from('sale_items')
          .select('sale_id,product_id,product_name,quantity,price_cents,cost_cents')
          .in('sale_id', saleIds)
          .abortSignal(signal)
      : { data: [], error: null };
    if (linesResult.error) throwSupabaseError(linesResult.error);
    const linesBySale = new Map<string, SaleItemRow[]>();
    for (const line of linesResult.data ?? []) {
      const current = linesBySale.get(line.sale_id) ?? [];
      current.push(line);
      linesBySale.set(line.sale_id, current);
    }
    return pageSchema(saleSchema).parse({
      items: sales.map((row) => mapDetail(row, linesBySale.get(row.id) ?? []).sale),
      total: count ?? 0,
      page,
      pageSize,
    });
  },
  async detail(id: string, signal: AbortSignal) {
    const { data, error } = await supabase
      .from('sales')
      .select(saleSelect)
      .eq('id', id)
      .abortSignal(signal)
      .single();
    if (error) throwSupabaseError(error);
    const lines = await supabase
      .from('sale_items')
      .select('product_id,product_name,quantity,price_cents,cost_cents')
      .eq('sale_id', id)
      .abortSignal(signal);
    if (lines.error) throwSupabaseError(lines.error);
    return mapDetail(data as unknown as SaleRow, lines.data as unknown as SaleItemRow[]);
  },
  async create(input: SaleInput, key: string) {
    const { data, error } = await supabase.rpc('create_sale', { p_input: input, p_key: key });
    if (error) throwSupabaseError(error);
    return detailSchema.parse(data);
  },
  async complete(id: string) {
    const { data, error } = await supabase.rpc('complete_order', { p_sale_id: id });
    if (error) throwSupabaseError(error);
    return detailSchema.parse(data);
  },
  async cancel(id: string, reason: string) {
    const { data, error } = await supabase.rpc('cancel_order', { p_sale_id: id, p_reason: reason });
    if (error) throwSupabaseError(error);
    return data;
  },
};
