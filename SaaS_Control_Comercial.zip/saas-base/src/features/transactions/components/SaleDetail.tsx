import { money } from '@saas/domain';
import { useSaleDetail } from '../hooks/useTransactions';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
export function SaleDetail({ id, onClose }: { id: string; onClose: () => void }) {
  const query = useSaleDetail(id);
  return (
    <Modal
      title={
        query.data?.sale.orderCode ? `Pedido ${query.data.sale.orderCode}` : 'Detalle de operación'
      }
      onClose={onClose}
      wide
    >
      <Feedback error={query.error} />
      {query.isPending ? (
        <p>Cargando…</p>
      ) : (
        query.data && (
          <div className="table-scroll">
            <table role="table">
              <thead role="rowgroup">
                <tr role="row">
                  <th role="columnheader" scope="col">
                    Artículo
                  </th>
                  <th role="columnheader" scope="col">
                    Cantidad
                  </th>
                  <th role="columnheader" scope="col">
                    Venta unitaria
                  </th>
                  <th role="columnheader" scope="col">
                    Costo unitario
                  </th>
                  <th role="columnheader" scope="col">
                    Total venta
                  </th>
                  <th role="columnheader" scope="col">
                    Total costo
                  </th>
                  <th role="columnheader" scope="col">
                    Utilidad bruta
                  </th>
                </tr>
              </thead>
              <tbody role="rowgroup">
                {query.data.items.map((i) => (
                  <tr role="row" key={i.productId}>
                    <td role="cell" data-label="Artículo">
                      {i.name}
                    </td>
                    <td role="cell" data-label="Cantidad">
                      {i.quantity}
                    </td>
                    <td role="cell" data-label="Venta unitaria">
                      {money(i.priceCents)}
                    </td>
                    <td role="cell" data-label="Costo unitario">
                      {money(i.costCents)}
                    </td>
                    <td role="cell" data-label="Total venta">
                      {money(i.salesCents)}
                    </td>
                    <td role="cell" data-label="Total costo">
                      {money(i.costTotalCents)}
                    </td>
                    <td role="cell" data-label="Utilidad bruta">
                      {money(i.grossCents)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}
    </Modal>
  );
}
