import { useProducts } from '@/features/products/hooks/useProducts';
import { act, cleanup, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { SaleComposer } from './SaleComposer';

const { mutate } = vi.hoisted(() => ({ mutate: vi.fn() }));
vi.mock('../hooks/useTransactions', () => ({
  useTransactionAction: () => ({ mutate, isPending: false, error: null }),
}));
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ children }: { children: ReactNode }) => <div>{children}</div>,
}));
vi.mock('@/features/products/hooks/useProducts', () => ({
  useProducts: vi.fn(() => ({
    isPending: false,
    isFetching: false,
    error: null,
    data: {
      page: 1,
      pageSize: 25,
      total: 2,
      items: [
        {
          id: '00000000-0000-4000-8000-000000000001',
          name: 'Guantes',
          sku: 'PRD-000001',
          priceCents: 2000,
          costCents: 1200,
          retailStock: 2,
          ordersStock: 0,
          active: true,
        },
        {
          id: '00000000-0000-4000-8000-000000000002',
          name: 'Lentes',
          sku: 'PRD-000002',
          priceCents: 1000,
          costCents: 600,
          retailStock: 0,
          ordersStock: 0,
          active: true,
        },
      ],
    },
  })),
}));
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('Sales workbench', () => {
  async function search(user: ReturnType<typeof userEvent.setup>) {
    await user.type(screen.getByLabelText('Buscar por nombre o código'), 'gu');
  }
  async function detail(user: ReturnType<typeof userEvent.setup>, count: number) {
    await user.click(screen.getByRole('button', { name: `Detalle (${count})` }));
  }
  it('combines repeated additions, respects stock and sends editable snapshots', async () => {
    const user = userEvent.setup();
    render(<SaleComposer channel="retail" onDone={vi.fn()} />);
    await search(user);
    expect(screen.getByRole('button', { name: 'Agregar Lentes' })).toBeDisabled();
    await user.click(screen.getByRole('button', { name: 'Agregar Guantes' }));
    await user.click(screen.getByRole('button', { name: 'Agregar Guantes' }));
    expect(screen.getByRole('button', { name: 'Agregar Guantes' })).toBeDisabled();
    await detail(user, 1);
    expect(screen.getByRole('spinbutton', { name: 'Cantidad de Guantes' })).toHaveValue(2);
    const price = screen.getByRole('spinbutton', { name: 'Precio de Guantes' });
    await user.clear(price);
    await user.type(price, '18.50');
    await user.click(screen.getByRole('button', { name: 'Confirmar venta' }));
    expect(mutate.mock.calls[0]?.[0].input.items).toEqual([
      {
        productId: '00000000-0000-4000-8000-000000000001',
        quantity: 2,
        priceCents: 1850,
        costCents: 1200,
      },
    ]);
  });
  it('blocks a manually typed quantity above retail stock', async () => {
    const user = userEvent.setup();
    render(<SaleComposer channel="retail" onDone={vi.fn()} />);
    await search(user);
    await user.click(screen.getByRole('button', { name: 'Agregar Guantes' }));
    await detail(user, 1);
    const quantity = screen.getByRole('spinbutton', { name: 'Cantidad de Guantes' });
    await user.clear(quantity);
    await user.type(quantity, '3');
    expect(screen.getByRole('alert')).toHaveTextContent('supera el stock');
    expect(screen.getByRole('button', { name: 'Confirmar venta' })).toBeDisabled();
    expect(mutate).not.toHaveBeenCalled();
  });
  it('allows an order without stock and preserves customer and delivery date', async () => {
    const user = userEvent.setup();
    render(<SaleComposer channel="orders" onDone={vi.fn()} />);
    await user.type(screen.getByLabelText('Cliente'), 'Empresa cliente');
    await user.type(screen.getByLabelText('Entrega prevista (opcional)'), '2026-11-02');
    await search(user);
    await user.click(screen.getByRole('button', { name: 'Agregar Lentes' }));
    await detail(user, 1);
    await user.click(screen.getByRole('button', { name: 'Guardar pedido pendiente' }));
    expect(mutate.mock.calls[0]?.[0].input).toMatchObject({
      channel: 'orders',
      customer: 'Empresa cliente',
      scheduledFor: '2026-11-02',
      items: [{ quantity: 1, priceCents: 1000, costCents: 600 }],
    });
  });
  it('shows all added lines in Detail and preserves edits across tabs', async () => {
    const user = userEvent.setup();
    render(<SaleComposer channel="orders" onDone={vi.fn()} />);
    await user.type(screen.getByLabelText('Cliente'), 'Cliente');
    await search(user);
    await user.click(screen.getByRole('button', { name: 'Agregar Guantes' }));
    await user.click(screen.getByRole('button', { name: 'Agregar Lentes' }));
    await detail(user, 2);
    expect(screen.getByRole('spinbutton', { name: 'Precio de Guantes' })).toHaveValue(20);
    const price = screen.getByRole('spinbutton', { name: 'Precio de Lentes' });
    await user.clear(price);
    await user.type(price, '13');
    await user.click(screen.getByRole('button', { name: 'Venta' }));
    await detail(user, 2);
    expect(screen.getByRole('spinbutton', { name: 'Precio de Lentes' })).toHaveValue(13);
    await user.click(screen.getByRole('button', { name: 'Guardar pedido pendiente' }));
    expect(mutate.mock.calls[0]?.[0].input.items).toHaveLength(2);
    expect(mutate.mock.calls[0]?.[0].input.items[1].priceCents).toBe(1300);
  });
  it('keeps customer/payment in the first tab and restores it for missing customer validation', async () => {
    const user = userEvent.setup();
    render(<SaleComposer channel="orders" onDone={vi.fn()} />);
    const sections = within(screen.getByRole('navigation', { name: 'Secciones de la operación' }));
    expect(sections.getAllByRole('button')).toHaveLength(2);
    await search(user);
    await user.click(screen.getByRole('button', { name: 'Agregar Lentes' }));
    await detail(user, 1);
    expect(screen.queryByRole('textbox', { name: 'Cliente' })).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Guardar pedido pendiente' }));
    expect(sections.getByRole('button', { name: 'Venta' })).toHaveAttribute('aria-pressed', 'true');
    expect(screen.getByRole('textbox', { name: 'Cliente' })).toBeVisible();
    expect(mutate).not.toHaveBeenCalled();
  });
  it('shows no product choices before typing and hides them again when clearing search', async () => {
    const user = userEvent.setup();
    render(<SaleComposer channel="retail" onDone={vi.fn()} />);
    expect(screen.queryByRole('button', { name: 'Agregar Guantes' })).not.toBeInTheDocument();
    expect(screen.queryByText('Consultando inventario…')).not.toBeInTheDocument();
    await search(user);
    expect(screen.getByRole('button', { name: 'Agregar Guantes' })).toBeVisible();
    await user.click(screen.getByRole('button', { name: 'Limpiar búsqueda' }));
    expect(screen.queryByRole('button', { name: 'Agregar Guantes' })).not.toBeInTheDocument();
  });
  it('shows the complete desktop workspace and preserves the draft when switching to mobile', async () => {
    let desktop = true;
    let notify = () => {};
    vi.stubGlobal('matchMedia', () => ({
      matches: desktop,
      addEventListener: (_event: string, handler: () => void) => {
        notify = handler;
      },
      removeEventListener: vi.fn(),
    }));
    const user = userEvent.setup();
    render(<SaleComposer channel="retail" onDone={vi.fn()} />);
    expect(
      screen.queryByRole('navigation', { name: 'Secciones de la operación' }),
    ).not.toBeInTheDocument();
    await search(user);
    await user.click(screen.getByRole('button', { name: 'Agregar Guantes' }));
    expect(screen.getByLabelText('Cantidad de Guantes')).toBeVisible();
    expect(screen.getByLabelText('Buscar por nombre o código')).toBeVisible();
    act(() => {
      desktop = false;
      notify();
    });
    await detail(user, 1);
    const price = screen.getByLabelText('Precio de Guantes');
    await user.clear(price);
    await user.type(price, '17');
    act(() => {
      desktop = true;
      notify();
    });
    expect(screen.getByLabelText('Precio de Guantes')).toHaveValue(17);
    expect(screen.getByLabelText('Buscar por nombre o código')).toHaveValue('gu');
    expect(
      screen.queryByRole('navigation', { name: 'Secciones de la operación' }),
    ).not.toBeInTheDocument();
  });
  it('requests only the rows that fit the results viewport', async () => {
    const original = HTMLElement.prototype.getBoundingClientRect;
    vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockImplementation(function (
      this: HTMLElement,
    ) {
      return this.classList.contains('inventory-results')
        ? new DOMRect(0, 0, 320, 216)
        : original.call(this);
    });
    const user = userEvent.setup();
    render(<SaleComposer channel="retail" onDone={vi.fn()} />);
    await search(user);
    expect(vi.mocked(useProducts).mock.calls.at(-1)?.[3]).toBe(3);
    expect(screen.getByRole('button', { name: 'Siguiente' })).toBeVisible();
  });
});
