import { useMediaQuery } from '@/shared/hooks/useMediaQuery';
import { errorMessage } from '@/shared/lib/error-message';
import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import {
  calculateLine,
  channelLabels,
  money,
  parseMoney,
  paymentLabels,
  saleInput,
} from '@saas/domain';
import type { Channel, Product } from '@saas/domain';
import { Minus, Plus, ShoppingCart, Trash2 } from 'lucide-react';
import { CatalogInventory } from './CatalogInventory';
import { useTransactionAction } from '../hooks/useTransactions';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
type Draft = { product: Product; quantity: string; price: string; cost: string };
export function SaleComposer({ channel, onDone }: { channel: Channel; onDone: () => void }) {
  const desktop = useMediaQuery('(min-width: 960px)');
  const [tab, setTab] = useState<'inventory' | 'detail'>('inventory');
  const formRef = useRef<HTMLFormElement>(null);
  const [items, setItems] = useState<Draft[]>([]);
  const [error, setError] = useState('');
  const action = useTransactionAction();
  const key = useRef(crypto.randomUUID());
  function switchTab(next: 'inventory' | 'detail') {
    setTab(next);
    formRef.current?.querySelector('.checkout-stage')?.scrollTo?.({ top: 0 });
  }
  function change(index: number, field: 'quantity' | 'price' | 'cost', value: string) {
    setItems((previous) =>
      previous.map((item, i) => (i === index ? { ...item, [field]: value } : item)),
    );
    key.current = crypto.randomUUID();
  }
  function add(product: Product) {
    setItems((previous) => {
      const currentQuantity = Number(
        previous.find((i) => i.product.id === product.id)?.quantity || 0,
      );
      if (
        !product.active ||
        currentQuantity >= 100000 ||
        (channel === 'retail' && currentQuantity >= product.retailStock) ||
        (previous.length >= 100 && !previous.some((i) => i.product.id === product.id))
      )
        return previous;
      const existing = previous.find((i) => i.product.id === product.id);
      return existing
        ? previous.map((i) =>
            i.product.id === product.id
              ? { ...i, quantity: String(Number(i.quantity || 0) + 1) }
              : i,
          )
        : [
            ...previous,
            {
              product,
              quantity: '1',
              price: (product.priceCents / 100).toFixed(2),
              cost: (product.costCents / 100).toFixed(2),
            },
          ];
    });
    key.current = crypto.randomUUID();
  }
  const computed = items.map((item) => {
    try {
      return calculateLine(Number(item.quantity), parseMoney(item.price), parseMoney(item.cost));
    } catch {
      return null;
    }
  });
  const totals = computed.reduce<{
    salesCents: number;
    costTotalCents: number;
    grossCents: number;
  }>(
    (total, item) => ({
      salesCents: total.salesCents + (item?.salesCents ?? 0),
      costTotalCents: total.costTotalCents + (item?.costTotalCents ?? 0),
      grossCents: total.grossCents + (item?.grossCents ?? 0),
    }),
    { salesCents: 0, costTotalCents: 0, grossCents: 0 },
  );
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    try {
      if (channel === 'orders' && !String(data.get('customer') ?? '').trim()) {
        switchTab('inventory');
        throw new Error('Indica el cliente del pedido.');
      }
      const invalid = computed.findIndex((line) => !line);
      if (invalid >= 0) {
        switchTab('detail');
        throw new Error('Revisa cantidad, precio y costo del artículo seleccionado.');
      }
      if (stockExceeded) {
        switchTab('detail');
      }
      if (stockExceeded) throw new Error('La cantidad supera el stock de menudeo disponible.');
      const input = saleInput.parse({
        channel,
        payment: data.get('payment'),
        customer: data.get('customer') ?? '',
        scheduledFor: data.get('scheduledFor') || null,
        items: items.map((i) => ({
          productId: i.product.id,
          quantity: Number(i.quantity),
          priceCents: parseMoney(i.price),
          costCents: parseMoney(i.cost),
        })),
      });
      setError('');
      action.mutate({ kind: 'create', input, key: key.current }, { onSuccess: onDone });
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  const quantities = new Map(items.map((item) => [item.product.id, Number(item.quantity) || 0]));
  const stockExceeded =
    channel === 'retail' && items.some((item) => Number(item.quantity) > item.product.retailStock);
  const unitCount = items.reduce((total, item) => total + (Number(item.quantity) || 0), 0);
  return (
    <Modal
      title={channel === 'retail' ? 'Venta de menudeo' : 'Crear pedido'}
      onClose={onDone}
      busy={action.isPending}
      wide
      fitted
      className="sale-composer-modal"
    >
      <form
        ref={formRef}
        onSubmit={submit}
        className={`sale-checkout checkout-tab-${tab}`}
        noValidate
      >
        <fieldset disabled={action.isPending}>
          <nav hidden={desktop} className="checkout-tabs" aria-label="Secciones de la operación">
            <button
              type="button"
              aria-pressed={tab === 'inventory'}
              onClick={() => switchTab('inventory')}
            >
              Venta
            </button>
            <button
              type="button"
              aria-pressed={tab === 'detail'}
              onClick={() => switchTab('detail')}
            >
              Detalle ({items.length})
            </button>
          </nav>
          <div className="checkout-stage">
            <div className="sale-workbench">
              <div className="inventory-pane" hidden={!desktop && tab !== 'inventory'}>
                <section className="sale-context" aria-label="Datos de la operación">
                  <div className="field">
                    <label htmlFor="customer">
                      Cliente {channel === 'retail' ? '(opcional)' : ''}
                    </label>
                    <input
                      id="customer"
                      name="customer"
                      placeholder={
                        channel === 'retail' ? 'Venta de mostrador' : 'Nombre del cliente'
                      }
                      maxLength={120}
                      required={channel === 'orders'}
                      onChange={() => {
                        key.current = crypto.randomUUID();
                      }}
                    />
                  </div>
                  <div className="field">
                    <label htmlFor="payment">
                      Método de pago{channel === 'orders' ? ' previsto' : ''}
                    </label>
                    <select
                      id="payment"
                      name="payment"
                      onChange={() => {
                        key.current = crypto.randomUUID();
                      }}
                    >
                      {Object.entries(paymentLabels).map(([value, label]) => (
                        <option key={value} value={value}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </div>
                  {channel === 'orders' && (
                    <div className="field">
                      <label htmlFor="scheduled">Entrega prevista (opcional)</label>
                      <input
                        id="scheduled"
                        type="date"
                        name="scheduledFor"
                        onChange={() => {
                          key.current = crypto.randomUUID();
                        }}
                      />
                    </div>
                  )}
                </section>

                <CatalogInventory
                  channel={channel}
                  quantities={quantities}
                  onAdd={add}
                  active={desktop || tab === 'inventory'}
                />
              </div>
              <section
                className="sale-basket"
                hidden={!desktop && tab !== 'detail'}
                aria-labelledby="basket-title"
              >
                <header className="workbench-heading">
                  <div>
                    <h2 id="basket-title">
                      {channel === 'retail' ? 'Detalle de venta' : 'Detalle de pedido'}
                    </h2>
                  </div>
                  <span className="badge" role="status">
                    {items.length} artículos · {unitCount} unidades
                  </span>
                </header>
                {!items.length && (
                  <div className="basket-empty">
                    <ShoppingCart size={38} />
                    <h3>Agrega tu primer artículo</h3>
                    <p>
                      Busca en el inventario y pulsa +. Aquí podrás ajustar cantidades, precio y
                      costo antes de confirmar.
                    </p>
                  </div>
                )}
                <div className="basket-lines">
                  {items.map((item, index) => {
                    const line = computed[index];
                    const exceeded =
                      channel === 'retail' && Number(item.quantity) > item.product.retailStock;
                    return (
                      <article className="basket-line" key={item.product.id}>
                        <div className="basket-line-heading">
                          <div>
                            <strong>{item.product.name}</strong>
                            <small>
                              {item.product.sku} · Stock{' '}
                              {channel === 'retail'
                                ? item.product.retailStock
                                : item.product.ordersStock}
                            </small>
                          </div>
                          <button
                            type="button"
                            className="basket-remove"
                            aria-label={`Quitar ${item.product.name}`}
                            onClick={() => {
                              setItems((previous) => previous.filter((_, i) => i !== index));
                              key.current = crypto.randomUUID();
                            }}
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                        <div className="basket-line-fields">
                          <div className="field">
                            <label htmlFor={`quantity-${item.product.id}`}>Cantidad</label>
                            <div className="quantity-control">
                              <button
                                type="button"
                                aria-label={`Reducir cantidad de ${item.product.name}`}
                                disabled={Number(item.quantity) <= 1}
                                onClick={() =>
                                  change(
                                    index,
                                    'quantity',
                                    String(Math.max(1, (Number(item.quantity) || 1) - 1)),
                                  )
                                }
                              >
                                <Minus size={16} />
                              </button>
                              <input
                                id={`quantity-${item.product.id}`}
                                aria-label={`Cantidad de ${item.product.name}`}
                                type="number"
                                inputMode="numeric"
                                min="1"
                                max="100000"
                                step="1"
                                value={item.quantity}
                                onChange={(e) => change(index, 'quantity', e.target.value)}
                                required
                              />
                              <button
                                type="button"
                                aria-label={`Aumentar cantidad de ${item.product.name}`}
                                disabled={
                                  Number(item.quantity) >= 100000 ||
                                  (channel === 'retail' &&
                                    Number(item.quantity) >= item.product.retailStock)
                                }
                                onClick={() =>
                                  change(
                                    index,
                                    'quantity',
                                    String((Number(item.quantity) || 0) + 1),
                                  )
                                }
                              >
                                <Plus size={16} />
                              </button>
                            </div>
                          </div>
                          <div className="field">
                            <label htmlFor={`price-${item.product.id}`}>Precio S/</label>
                            <input
                              id={`price-${item.product.id}`}
                              aria-label={`Precio de ${item.product.name}`}
                              type="number"
                              inputMode="decimal"
                              min="0"
                              max="1000000"
                              step="0.01"
                              value={item.price}
                              onChange={(e) => change(index, 'price', e.target.value)}
                              required
                            />
                          </div>
                          <div className="field">
                            <label htmlFor={`cost-${item.product.id}`}>Costo S/</label>
                            <input
                              id={`cost-${item.product.id}`}
                              aria-label={`Costo de ${item.product.name}`}
                              type="number"
                              inputMode="decimal"
                              min="0"
                              max="1000000"
                              step="0.01"
                              value={item.cost}
                              onChange={(e) => change(index, 'cost', e.target.value)}
                              required
                            />
                          </div>
                        </div>
                        {exceeded && (
                          <p className="field-error" role="alert">
                            La cantidad supera el stock de menudeo disponible.
                          </p>
                        )}
                        {!line && (
                          <p className="field-error">
                            Revisa cantidad, precio y costo de este artículo.
                          </p>
                        )}
                        <dl className="basket-line-totals">
                          <div>
                            <dt>Total venta</dt>
                            <dd>{line ? money(line.salesCents) : '—'}</dd>
                          </div>
                          <div>
                            <dt>Total costo</dt>
                            <dd>{line ? money(line.costTotalCents) : '—'}</dd>
                          </div>
                          <div>
                            <dt>Utilidad bruta</dt>
                            <dd className={(line?.grossCents ?? 0) < 0 ? 'negative' : ''}>
                              {line ? money(line.grossCents) : '—'}
                            </dd>
                          </div>
                        </dl>
                      </article>
                    );
                  })}
                </div>
              </section>
            </div>
          </div>
          <section className="checkout-summary" aria-label="Resumen de operación">
            <div className="checkout-amounts">
              <div>
                <span>Total a {channel === 'retail' ? 'cobrar' : 'programar'}</span>
                <strong>{money(totals.salesCents)}</strong>
              </div>
              <div>
                <span>Costo total</span>
                <strong>{money(totals.costTotalCents)}</strong>
              </div>
              <div>
                <span>Utilidad bruta</span>
                <strong className={totals.grossCents < 0 ? 'negative' : ''}>
                  {money(totals.grossCents)}
                </strong>
              </div>
            </div>
            {totals.grossCents < 0 && (
              <p className="field-error">
                La operación tiene utilidad negativa. Revisa los precios antes de confirmar.
              </p>
            )}
            <Feedback error={error || action.error} />
            <p className="checkout-note">
              {channelLabels[channel]} · Fecha y hora automáticas.{' '}
              {channel === 'orders'
                ? 'El pedido no reserva stock ni genera ingresos hasta entregarlo.'
                : 'El stock se validará nuevamente al confirmar la venta.'}
            </p>
            <div className="checkout-actions">
              <button type="button" className="button secondary" onClick={onDone}>
                Cancelar
              </button>
              <button
                type="submit"
                className="button primary"
                disabled={!items.length || computed.some((value) => !value) || stockExceeded}
              >
                {action.isPending
                  ? 'Guardando…'
                  : channel === 'retail'
                    ? 'Confirmar venta'
                    : 'Guardar pedido pendiente'}
              </button>
            </div>
          </section>
        </fieldset>
      </form>
    </Modal>
  );
}
