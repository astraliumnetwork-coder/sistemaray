import { useSearchParams } from 'react-router-dom';
import { Modal } from '@/shared/ui/Modal';
import { useState } from 'react';
import type { FormEvent } from 'react';
import { channelLabels, money, paymentLabels } from '@saas/domain';
import type { Channel } from '@saas/domain';
import { useTransactions, useTransactionAction } from '../hooks/useTransactions';
import { SaleComposer } from './SaleComposer';
import { SaleDetail } from './SaleDetail';
import { Pagination } from '@/shared/ui/Pagination';
import { Feedback } from '@/shared/ui/Feedback';
const statusLabels = { posted: 'Contabilizado', pending: 'Pendiente', cancelled: 'Anulado' };
export function SalesWorkspace({ channel }: { channel: Channel }) {
  const [searchParams, setSearchParams] = useSearchParams();
  const [complete, setComplete] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [compose, setCompose] = useState(false);
  const [detail, setDetail] = useState<string | null>(null);
  const [cancel, setCancel] = useState<string | null>(null);
  const query = useTransactions(channel, page);
  const action = useTransactionAction();
  function cancelSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    action.mutate(
      { kind: 'cancel', id: cancel!, reason: String(new FormData(e.currentTarget).get('reason')) },
      { onSuccess: () => setCancel(null) },
    );
  }
  return (
    <div className="page sales-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">REGISTRO COMERCIAL</p>
          <h1>{channelLabels[channel]}</h1>
          <p className="muted">
            {channel === 'retail'
              ? 'Ventas de mostrador con cálculo y salida de stock inmediata.'
              : 'Pedidos programados, con reconocimiento al entregar.'}
          </p>
        </div>
        <button className="button primary" onClick={() => setCompose(true)}>
          {channel === 'retail' ? 'Nueva venta' : 'Nuevo pedido'}
        </button>
      </div>
      {(compose || searchParams.has('nueva')) && (
        <SaleComposer
          channel={channel}
          onDone={() => {
            setCompose(false);
            if (searchParams.has('nueva')) {
              const next = new URLSearchParams(searchParams);
              next.delete('nueva');
              setSearchParams(next, { replace: true });
            }
          }}
        />
      )}
      {detail && <SaleDetail id={detail} onClose={() => setDetail(null)} />}
      {cancel && (
        <Modal title="Anular pedido" onClose={() => setCancel(null)} busy={action.isPending}>
          <form className="settings-form" onSubmit={cancelSubmit}>
            <fieldset disabled={action.isPending}>
              <div className="field">
                <label htmlFor="cancel-reason">Motivo de anulación del pedido</label>
                <input id="cancel-reason" name="reason" required minLength={3} maxLength={200} />
              </div>
              <div className="modal-actions">
                <button className="button primary" disabled={action.isPending}>
                  Confirmar anulación
                </button>
                <button type="button" className="button secondary" onClick={() => setCancel(null)}>
                  Volver
                </button>
              </div>
            </fieldset>
            <Feedback error={action.error} />
          </form>
        </Modal>
      )}
      {complete && (
        <Modal title="Entregar pedido" onClose={() => setComplete(null)} busy={action.isPending}>
          <p>
            Al confirmar, se descontará el stock de pedidos y se contabilizará la venta. Esta
            operación no se puede repetir.
          </p>
          <Feedback error={action.error} />
          <div className="modal-actions">
            <button
              className="button secondary"
              disabled={action.isPending}
              onClick={() => setComplete(null)}
            >
              Volver
            </button>
            <button
              className="button primary"
              disabled={action.isPending}
              onClick={() =>
                action.mutate(
                  { kind: 'complete', id: complete },
                  { onSuccess: () => setComplete(null) },
                )
              }
            >
              {action.isPending ? 'Entregando…' : 'Confirmar entrega'}
            </button>
          </div>
        </Modal>
      )}
      <section className="panel">
        <div className="section-heading">
          <h2>Historial de {channelLabels[channel].toLowerCase()}</h2>
        </div>
        <Feedback error={query.error} />
        {query.isPending ? (
          <p>Cargando movimientos…</p>
        ) : (
          query.data && (
            <>
              <div className="table-scroll">
                <table role="table" className={`sales-history-table sales-history-${channel}`}>
                  <colgroup>
                    <col className="history-identity-col" />
                    <col className="history-payment-col" />
                    <col className="history-status-col" />
                    <col className="history-money-col" />
                    <col className="history-money-col" />
                    <col className="history-money-col" />
                    {channel === 'orders' && <col className="history-actions-col" />}
                  </colgroup>
                  <thead role="rowgroup">
                    <tr role="row">
                      <th role="columnheader" scope="col">
                        {channel === 'orders' ? 'Pedido / Fecha / Cliente' : 'Fecha / Cliente'}
                      </th>
                      <th role="columnheader" scope="col">
                        Pago
                      </th>
                      <th role="columnheader" scope="col">
                        Estado
                      </th>
                      <th role="columnheader" scope="col">
                        Total venta
                      </th>
                      <th role="columnheader" scope="col">
                        Total costo
                      </th>
                      <th role="columnheader" scope="col">
                        Utilidad bruta
                      </th>
                      {channel === 'orders' && (
                        <th role="columnheader" scope="col">
                          Acciones
                        </th>
                      )}
                    </tr>
                  </thead>
                  <tbody role="rowgroup">
                    {query.data.items.map((s) => (
                      <tr role="row" key={s.id}>
                        <td
                          role="cell"
                          data-label={
                            channel === 'orders' ? 'Pedido / Fecha / Cliente' : 'Fecha / Cliente'
                          }
                        >
                          {channel === 'orders' && (
                            <span className="order-code">{s.orderCode ?? '—'}</span>
                          )}
                          <strong>
                            {new Intl.DateTimeFormat('es-PE', {
                              timeZone: 'America/Lima',
                              dateStyle: 'short',
                              timeStyle: 'short',
                            }).format(new Date(s.createdAt))}
                          </strong>
                          <small>{s.customer || 'Venta de mostrador'}</small>
                          {s.scheduledFor && (
                            <small className="delivery-date">
                              Entrega: {s.scheduledFor.split('-').reverse().join('/')}
                            </small>
                          )}
                        </td>
                        <td role="cell" data-label="Pago">
                          {paymentLabels[s.payment]}
                        </td>
                        <td role="cell" data-label="Estado">
                          <span className={`badge status-${s.status}`}>
                            {statusLabels[s.status]}
                          </span>
                        </td>
                        <td role="cell" data-label="Total venta">
                          {money(s.salesCents)}
                        </td>
                        <td role="cell" data-label="Total costo">
                          {money(s.costTotalCents)}
                        </td>
                        <td
                          role="cell"
                          data-label="Utilidad bruta"
                          className={s.grossCents < 0 ? 'negative' : ''}
                        >
                          {money(s.grossCents)}
                        </td>
                        {channel === 'orders' && (
                          <td role="cell" data-label="Acciones">
                            <div className="row-actions">
                              <button className="button secondary" onClick={() => setDetail(s.id)}>
                                Detalle
                              </button>
                              {channel === 'orders' && s.status === 'pending' && (
                                <>
                                  <button
                                    className="button primary"
                                    disabled={action.isPending}
                                    onClick={() => {
                                      action.reset();
                                      setComplete(s.id);
                                    }}
                                  >
                                    Entregar
                                  </button>
                                  <button
                                    className="text-button danger"
                                    onClick={() => {
                                      action.reset();
                                      setCancel(s.id);
                                    }}
                                  >
                                    Anular
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!query.data.items.length && (
                <p className="empty-state">Aún no hay operaciones en esta línea.</p>
              )}
              <Pagination {...query.data} onChange={setPage} />
            </>
          )
        )}
      </section>
    </div>
  );
}
