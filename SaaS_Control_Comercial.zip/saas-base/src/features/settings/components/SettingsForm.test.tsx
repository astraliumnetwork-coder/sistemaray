import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { QueryClientProvider } from '@tanstack/react-query';
import { createQueryClient } from '@/app/query-client';
import { SettingsForm } from './SettingsForm';
import { defaultSettings } from '../model/settings';
import { settingsRepository } from '../api/settings.repository';
vi.mock('@/features/auth/hooks/useSession', () => ({ useTenantId: () => 'tenant-test' }));
describe('configuración del espacio', () => {
  it('valida antes de guardar y envía el cambio al repositorio', async () => {
    const save = vi.spyOn(settingsRepository, 'save').mockImplementation(async (v) => v);
    const user = userEvent.setup();
    render(
      <QueryClientProvider client={createQueryClient()}>
        <SettingsForm initialValues={defaultSettings} />
      </QueryClientProvider>,
    );
    const name = screen.getByLabelText('Nombre de la empresa');
    await user.clear(name);
    await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
    expect(await screen.findByText('Escribe al menos 2 caracteres.')).toBeInTheDocument();
    expect(save).not.toHaveBeenCalled();
    await user.type(name, 'Lifaza');
    await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
    expect(await screen.findByText('Cambios guardados.')).toBeInTheDocument();
    expect(save).toHaveBeenCalledWith(
      { ...defaultSettings, organizationName: 'Lifaza' },
      expect.anything(),
    );
  });
  it('no confirma guardado cuando el servidor falla', async () => {
    vi.spyOn(settingsRepository, 'save').mockRejectedValue(new Error('No disponible'));
    const user = userEvent.setup();
    render(
      <QueryClientProvider client={createQueryClient()}>
        <SettingsForm initialValues={defaultSettings} />
      </QueryClientProvider>,
    );
    await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
    expect(await screen.findByRole('alert')).toHaveTextContent('No se pudo guardar');
    expect(screen.queryByText('Cambios guardados.')).not.toBeInTheDocument();
  });
});
