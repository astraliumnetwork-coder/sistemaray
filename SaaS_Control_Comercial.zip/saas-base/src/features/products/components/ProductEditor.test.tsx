import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ReactNode } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ProductEditor } from './ProductEditor';
const { mutate } = vi.hoisted(() => ({ mutate: vi.fn() }));
vi.mock('../hooks/useProducts', () => ({
  useProductAction: () => ({ mutate, isPending: false, error: null }),
}));
vi.mock('@/shared/ui/Modal', () => ({
  Modal: ({ children }: { children: ReactNode }) => <div>{children}</div>,
}));
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
describe('Product editor', () => {
  it('creates a product with separate channel stock', async () => {
    const user = userEvent.setup();
    render(<ProductEditor onDone={vi.fn()} />);
    await user.type(screen.getByLabelText(/Nombre del producto/), 'Guantes');
    await user.type(screen.getByLabelText(/Precio de venta/), '15.50');
    await user.type(screen.getByLabelText(/Costo de compra/), '10');
    const stock = screen.getByLabelText('Cantidad inicial · Menudeo');
    await user.clear(stock);
    await user.type(stock, '3');
    await user.click(screen.getByRole('button', { name: 'Crear producto' }));
    expect(mutate.mock.calls[0]?.[0]).toMatchObject({
      kind: 'create',
      body: {
        sku: 'AUTO',
        name: 'Guantes',
        priceCents: 1550,
        costCents: 1000,
        retailStock: 3,
        ordersStock: 0,
        active: true,
      },
    });
  });
  it('allows zero price and shows a loss warning', async () => {
    const user = userEvent.setup();
    render(<ProductEditor onDone={vi.fn()} />);
    await user.type(screen.getByLabelText(/Nombre del producto/), 'Muestra');
    await user.type(screen.getByLabelText(/Precio de venta/), '0');
    await user.type(screen.getByLabelText(/Costo de compra/), '2');
    expect(screen.getByRole('status')).toHaveTextContent('pérdida');
    await user.click(screen.getByRole('button', { name: 'Crear producto' }));
    expect(mutate.mock.calls[0]?.[0].body.priceCents).toBe(0);
  });
  it('updates product fields without changing its code, inactive flag or stock', async () => {
    const user = userEvent.setup();
    render(
      <ProductEditor
        onDone={vi.fn()}
        product={{
          id: '00000000-0000-4000-8000-000000000001',
          sku: 'PRD-000001',
          name: 'Lentes',
          priceCents: 1000,
          costCents: 500,
          retailStock: 9,
          ordersStock: 4,
          active: false,
        }}
      />,
    );
    expect(screen.queryByLabelText('Cantidad inicial · Menudeo')).not.toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
    expect(mutate.mock.calls[0]?.[0]).toMatchObject({
      kind: 'update',
      id: '00000000-0000-4000-8000-000000000001',
      body: { sku: 'PRD-000001', active: false },
    });
    expect(mutate.mock.calls[0]?.[0].body).not.toHaveProperty('retailStock');
  });
});
