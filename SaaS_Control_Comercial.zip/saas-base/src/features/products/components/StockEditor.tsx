import { useRef } from 'react';
import type { FormEvent } from 'react';
import type { Product } from '@saas/domain';
import { useProductAction } from '../hooks/useProducts';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
export function StockEditor({ product, onDone }: { product: Product; onDone: () => void }) {
  const action = useProductAction();
  const key = useRef(crypto.randomUUID());
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    action.mutate(
      {
        kind: 'stock',
        id: product.id,
        key: key.current,
        body: {
          channel: data.get('channel'),
          delta: Number(data.get('delta')),
          reason: data.get('reason'),
        },
      },
      { onSuccess: onDone },
    );
  }
  return (
    <Modal title={`Ajustar stock · ${product.name}`} onClose={onDone} busy={action.isPending}>
      <form
        className="settings-form"
        onSubmit={submit}
        onChange={() => {
          key.current = crypto.randomUUID();
        }}
      >
        <fieldset disabled={action.isPending}>
          <div className="form-grid">
            <div className="field">
              <label htmlFor="stock-channel">Línea</label>
              <select id="stock-channel" name="channel">
                <option value="retail">Menudeo ({product.retailStock})</option>
                <option value="orders">Pedidos ({product.ordersStock})</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="delta">Unidades a sumar o restar</label>
              <input
                id="delta"
                name="delta"
                type="number"
                min="-1000000"
                max="1000000"
                step="1"
                required
              />
            </div>
          </div>
          <div className="field">
            <label htmlFor="reason">Motivo del ajuste</label>
            <input id="reason" name="reason" minLength={3} maxLength={200} required />
          </div>
          <button className="button primary">Aplicar ajuste</button>
        </fieldset>
        <Feedback error={action.error} />
      </form>
    </Modal>
  );
}
