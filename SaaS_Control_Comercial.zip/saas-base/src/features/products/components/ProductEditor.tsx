import { useState } from 'react';
import type { FormEvent } from 'react';
import { BadgeDollarSign, Boxes, Package, Save, ShoppingCart, Truck } from 'lucide-react';
import { money, parseMoney, productInput } from '@saas/domain';
import type { Product } from '@saas/domain';
import { errorMessage } from '@/shared/lib/error-message';
import { useProductAction } from '../hooks/useProducts';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';

export function ProductEditor({
  product,
  onDone,
  onSaved,
}: {
  product?: Product;
  onDone: () => void;
  onSaved?: (saved: { id: string; name: string }) => void;
}) {
  const action = useProductAction();
  const [error, setError] = useState('');
  const [name, setName] = useState(product?.name ?? '');
  const [price, setPrice] = useState(product ? (product.priceCents / 100).toFixed(2) : '');
  const [cost, setCost] = useState(product ? (product.costCents / 100).toFixed(2) : '');
  const [retail, setRetail] = useState(String(product?.retailStock ?? 0));
  const [orders, setOrders] = useState(String(product?.ordersStock ?? 0));
  let loss: number | null = null;
  try {
    loss = parseMoney(cost) - parseMoney(price);
  } catch {
    /* Amounts may be incomplete while typing. */
  }
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      const schema = product
        ? productInput.omit({ retailStock: true, ordersStock: true })
        : productInput;
      const input = schema.parse({
        sku: product?.sku ?? 'AUTO',
        name,
        priceCents: parseMoney(price),
        costCents: parseMoney(cost),
        retailStock: Number(retail),
        ordersStock: Number(orders),
      });
      setError('');
      action.mutate(
        {
          kind: product ? 'update' : 'create',
          ...(product ? { id: product.id } : {}),
          body: { ...input, active: product ? data.get('active') === 'on' : true },
        },
        {
          onSuccess: (result) => {
            const id = product?.id ?? (result && 'id' in result ? result.id : undefined);
            if (id) onSaved?.({ id, name: input.name });
            onDone();
          },
        },
      );
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  return (
    <Modal
      title={product ? 'Editar producto' : 'Nuevo producto'}
      onClose={onDone}
      busy={action.isPending}
      fitted
      className="product-editor-modal"
    >
      <form className="product-editor-form" onSubmit={submit}>
        <fieldset disabled={action.isPending}>
          <div className="product-editor-body">
            <div className="product-editor-sections">
              <section className="product-editor-section" aria-labelledby="product-identification">
                <header>
                  <span className="editor-section-icon">
                    <Package size={21} />
                  </span>
                  <div>
                    <small>01 · IDENTIFICACIÓN</small>
                    <h2 id="product-identification">Información del artículo</h2>
                  </div>
                </header>
                <div className="field">
                  <label htmlFor="product-name">
                    Nombre del producto <span aria-hidden="true">*</span>
                  </label>
                  <input
                    id="product-name"
                    name="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ej. Guantes de protección anticorte"
                    minLength={2}
                    maxLength={120}
                    required
                    autoComplete="off"
                  />
                  <p className="editor-field-hint">
                    Utiliza un nombre que permita distinguir modelo, talla o presentación.
                  </p>
                </div>
              </section>
              <section className="product-editor-section" aria-labelledby="product-pricing">
                <header>
                  <span className="editor-section-icon">
                    <BadgeDollarSign size={21} />
                  </span>
                  <div>
                    <small>02 · PRECIOS</small>
                    <h2 id="product-pricing">Venta y costo unitario</h2>
                  </div>
                  <span className="badge">PEN · Soles</span>
                </header>
                <div className="form-grid">
                  <div className="field">
                    <label htmlFor="price">Precio de venta (S/) *</label>
                    <input
                      id="price"
                      name="price"
                      type="number"
                      inputMode="decimal"
                      min="0"
                      max="1000000"
                      step="0.01"
                      placeholder="0.00"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      required
                    />
                  </div>
                  <div className="field">
                    <label htmlFor="cost">Costo de compra (S/) *</label>
                    <input
                      id="cost"
                      name="cost"
                      type="number"
                      inputMode="decimal"
                      min="0"
                      max="1000000"
                      step="0.01"
                      placeholder="0.00"
                      value={cost}
                      onChange={(e) => setCost(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <p className="editor-field-hint">
                  Importes por unidad. En cada venta podrás ajustar estos valores.
                </p>
                {loss !== null && loss > 0 && (
                  <p className="editor-loss" role="status">
                    El precio está por debajo del costo: pérdida de {money(loss)} por unidad.
                  </p>
                )}
                {product && (
                  <p className="editor-field-hint">
                    Los cambios no modifican los importes de ventas anteriores.
                  </p>
                )}
              </section>
              <section className="product-editor-section" aria-labelledby="product-inventory">
                <header>
                  <span className="editor-section-icon">
                    <Boxes size={21} />
                  </span>
                  <div>
                    <small>03 · INVENTARIO</small>
                    <h2 id="product-inventory">
                      {product ? 'Existencias por canal' : 'Distribución de stock inicial'}
                    </h2>
                  </div>
                </header>
                <div className="editor-stock-grid">
                  <div className="editor-stock-channel">
                    <span>
                      <ShoppingCart size={18} />
                      Menudeo
                    </span>
                    <p>Unidades para venta de mostrador</p>
                    {product ? (
                      <strong>{Number(retail).toLocaleString('es-PE')} unidades</strong>
                    ) : (
                      <div className="field">
                        <label htmlFor="retailStock">Cantidad inicial · Menudeo</label>
                        <input
                          id="retailStock"
                          name="retailStock"
                          type="number"
                          inputMode="numeric"
                          min="0"
                          max="1000000"
                          step="1"
                          value={retail}
                          onChange={(e) => setRetail(e.target.value)}
                          required
                        />
                      </div>
                    )}
                  </div>
                  <div className="editor-stock-channel">
                    <span>
                      <Truck size={18} />
                      Pedidos
                    </span>
                    <p>Unidades destinadas a despachos</p>
                    {product ? (
                      <strong>{Number(orders).toLocaleString('es-PE')} unidades</strong>
                    ) : (
                      <div className="field">
                        <label htmlFor="ordersStock">Cantidad inicial · Pedidos</label>
                        <input
                          id="ordersStock"
                          name="ordersStock"
                          type="number"
                          inputMode="numeric"
                          min="0"
                          max="1000000"
                          step="1"
                          value={orders}
                          onChange={(e) => setOrders(e.target.value)}
                          required
                        />
                      </div>
                    )}
                  </div>
                </div>
                <p className="editor-field-hint">
                  {product
                    ? 'Para registrar entradas o salidas, utiliza Ajustar stock desde el listado.'
                    : 'Puedes comenzar con cero. Cada canal mantiene existencias independientes.'}
                </p>
                {product && (
                  <label className="editor-availability">
                    <input name="active" type="checkbox" defaultChecked={product.active} />
                    <span>Disponible para nuevas ventas</span>
                  </label>
                )}
              </section>
            </div>
          </div>
          <footer className="product-editor-actions">
            <div>
              <Feedback error={error || action.error} />
              <span className="editor-field-hint">Los campos con * son obligatorios.</span>
            </div>
            <div>
              <button className="button secondary" type="button" onClick={onDone}>
                Cancelar
              </button>
              <button className="button primary" type="submit">
                <Save size={17} />
                {action.isPending ? 'Guardando…' : product ? 'Guardar cambios' : 'Crear producto'}
              </button>
            </div>
          </footer>
        </fieldset>
      </form>
    </Modal>
  );
}
