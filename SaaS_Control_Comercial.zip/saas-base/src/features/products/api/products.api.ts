import { z } from 'zod';
import { pageSchema, productSchema } from '@saas/domain';
import { supabase } from '@/shared/supabase/client';
import { throwSupabaseError } from '@/shared/supabase/errors';

export type ProductFilters = {
  searchBy?: 'all' | 'name' | 'sku';
  stock?: 'all' | 'retail-positive' | 'retail-zero' | 'orders-positive' | 'orders-zero';
  sort?: 'name-asc' | 'name-desc' | 'sku-asc' | 'price-asc' | 'price-desc';
  productId?: string;
};

type ProductRow = {
  id: string;
  sku: string;
  name: string;
  price_cents: number | string;
  cost_cents: number | string;
  active: boolean;
};

function mapProduct(row: ProductRow, inventory: { channel: string; quantity: number }[]) {
  return productSchema.parse({
    id: row.id,
    sku: row.sku,
    name: row.name,
    priceCents: Number(row.price_cents),
    costCents: Number(row.cost_cents),
    active: row.active,
    retailStock: inventory.find((stock) => stock.channel === 'retail')?.quantity ?? 0,
    ordersStock: inventory.find((stock) => stock.channel === 'orders')?.quantity ?? 0,
  });
}

export const productsApi = {
  async list(
    search: string,
    page: number,
    signal: AbortSignal,
    activeOnly = false,
    pageSize = 25,
    filters: ProductFilters = {},
  ) {
    const stockFilter = filters.stock ?? 'all';
    const [stockChannel, stockQuantity] = stockFilter.split('-');
    const sort = filters.sort ?? 'name-asc';
    const [sortField, sortDirection] = sort.split('-');
    let query = supabase
      .from('products')
      .select(
        stockFilter === 'all'
          ? 'id,sku,name,price_cents,cost_cents,active'
          : 'id,sku,name,price_cents,cost_cents,active,inventory!inner(channel,quantity)',
        { count: 'exact' },
      )
      .order(sortField === 'price' ? 'price_cents' : (sortField ?? 'name'), {
        ascending: sortDirection === 'asc',
      })
      .order('id')
      .range((page - 1) * pageSize, page * pageSize - 1)
      .abortSignal(signal);
    if (stockFilter !== 'all') {
      query = query.eq('inventory.channel', stockChannel);
      query =
        stockQuantity === 'zero'
          ? query.eq('inventory.quantity', 0)
          : query.gt('inventory.quantity', 0);
    }
    if (filters.productId) query = query.eq('id', filters.productId);
    if (activeOnly) query = query.eq('active', true);
    const normalizedSearch = search
      .trim()
      .slice(0, 100)
      .replace(/[\\%_,().]/g, '\\$&');
    if (normalizedSearch) {
      query =
        filters.searchBy && filters.searchBy !== 'all'
          ? query.ilike(filters.searchBy, `%${normalizedSearch}%`)
          : query.or(`name.ilike.%${normalizedSearch}%,sku.ilike.%${normalizedSearch}%`);
    }
    const { data, error, count } = await query;
    if (error) throwSupabaseError(error);
    const products = (data ?? []) as unknown as ProductRow[];
    const ids = products.map((product) => product.id);
    const inventoryResult = ids.length
      ? await supabase
          .from('inventory')
          .select('product_id,channel,quantity')
          .in('product_id', ids)
          .abortSignal(signal)
      : { data: [], error: null };
    if (inventoryResult.error) throwSupabaseError(inventoryResult.error);
    const stockByProduct = new Map<string, { channel: string; quantity: number }[]>();
    for (const stock of inventoryResult.data ?? []) {
      const current = stockByProduct.get(stock.product_id) ?? [];
      current.push({ channel: stock.channel, quantity: stock.quantity });
      stockByProduct.set(stock.product_id, current);
    }
    return pageSchema(productSchema).parse({
      items: products.map((product) => mapProduct(product, stockByProduct.get(product.id) ?? [])),
      total: count ?? 0,
      page,
      pageSize,
    });
  },
  async create(input: unknown) {
    const { data, error } = await supabase.rpc('create_product', { p_input: input });
    if (error) throwSupabaseError(error);
    return z.object({ id: z.string().uuid() }).parse({ id: data });
  },
  async update(id: string, input: unknown) {
    const value = z
      .object({
        sku: z.string().trim().min(1).max(40),
        name: z.string().trim().min(2).max(120),
        priceCents: z.number().int().min(0).max(100_000_000),
        costCents: z.number().int().min(0).max(100_000_000),
        active: z.boolean(),
      })
      .parse(input);
    const { error } = await supabase.rpc('update_product', {
      p_product_id: id,
      p_input: {
        sku: value.sku,
        name: value.name,
        priceCents: value.priceCents,
        costCents: value.costCents,
        active: value.active,
      },
    });
    if (error) throwSupabaseError(error);
  },
  async stock(id: string, input: unknown, key: string) {
    const value = z
      .object({
        channel: z.enum(['retail', 'orders']),
        delta: z
          .number()
          .int()
          .min(-1_000_000)
          .max(1_000_000)
          .refine((n) => n !== 0),
        reason: z.string().trim().min(3).max(200),
      })
      .parse(input);
    const { data, error } = await supabase.rpc('adjust_stock', {
      p_product_id: id,
      p_channel: value.channel,
      p_delta: value.delta,
      p_reason: value.reason,
      p_key: key,
    });
    if (error) throwSupabaseError(error);
    return { quantity: Number(data) };
  },
};
