import { useDeferredValue, useState } from 'react';
import { Package, Pencil, Plus, Search, SlidersHorizontal } from 'lucide-react';
import { money } from '@saas/domain';
import type { Product } from '@saas/domain';
import type { ProductFilters } from '../api/products.api';
import { useProducts } from '../hooks/useProducts';
import { ProductEditor } from '../components/ProductEditor';
import { StockEditor } from '../components/StockEditor';
import { Pagination } from '@/shared/ui/Pagination';
import { Feedback } from '@/shared/ui/Feedback';

export function Component() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [editor, setEditor] = useState<Product | 'new' | null>(null);
  const [stock, setStock] = useState<Product | null>(null);
  const [filters, setFilters] = useState<ProductFilters>({});
  const [pageSize, setPageSize] = useState(25);
  const [savedName, setSavedName] = useState('');
  const query = useProducts(useDeferredValue(search), page, false, pageSize, true, filters);
  function changeFilters(next: ProductFilters) {
    const cleared = { ...next };
    delete cleared.productId;
    setFilters(cleared);
    setSavedName('');
    setPage(1);
  }
  function clearFilters() {
    setSearch('');
    changeFilters({});
  }
  return (
    <div className="page products-page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">CATÁLOGO E INVENTARIO</p>
          <h1>Productos</h1>
          <p className="muted">Precios, rentabilidad y existencias por línea de negocio.</p>
        </div>
        <button
          className="button primary"
          onClick={() => {
            setEditor('new');
            setStock(null);
          }}
        >
          <Plus size={18} />
          Nuevo producto
        </button>
      </div>
      {editor && (
        <ProductEditor
          key={typeof editor === 'string' ? editor : editor.id}
          {...(editor === 'new' ? {} : { product: editor })}
          onDone={() => setEditor(null)}
          onSaved={({ id, name }) => {
            setSearch('');
            setFilters({ productId: id });
            setSavedName(name);
            setPage(1);
          }}
        />
      )}
      {stock && <StockEditor key={stock.id} product={stock} onDone={() => setStock(null)} />}
      <section className="panel products-panel">
        <div className="products-toolbar">
          <div>
            <h2>Catálogo de artículos</h2>
            <p className="muted" role="status">
              {query.data
                ? `${query.data.total} productos${search.trim() || Object.keys(filters).length ? ' encontrados' : ' registrados'}`
                : 'Consultando catálogo…'}
            </p>
          </div>
          <div className="field product-search">
            <label className="sr-only" htmlFor="product-search">
              Buscar por código o artículo
            </label>
            <Search size={18} aria-hidden="true" />
            <input
              id="product-search"
              placeholder="Buscar artículo o código…"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                changeFilters({ ...filters });
              }}
            />
          </div>
        </div>
        <div className="inventory-filters">
          <label className="field">
            Buscar en
            <select
              value={filters.searchBy ?? 'all'}
              onChange={(e) =>
                changeFilters({
                  ...filters,
                  searchBy: e.target.value as NonNullable<ProductFilters['searchBy']>,
                })
              }
            >
              <option value="all">Nombre y código</option>
              <option value="name">Nombre</option>
              <option value="sku">Código interno</option>
            </select>
          </label>
          <label className="field">
            Existencias
            <select
              value={filters.stock ?? 'all'}
              onChange={(e) =>
                changeFilters({
                  ...filters,
                  stock: e.target.value as NonNullable<ProductFilters['stock']>,
                })
              }
            >
              <option value="all">Todas las existencias</option>
              <option value="retail-positive">Menudeo · Con stock</option>
              <option value="retail-zero">Menudeo · Sin stock</option>
              <option value="orders-positive">Pedidos · Con stock</option>
              <option value="orders-zero">Pedidos · Sin stock</option>
            </select>
          </label>
          <label className="field">
            Ordenar por
            <select
              value={filters.sort ?? 'name-asc'}
              onChange={(e) =>
                changeFilters({
                  ...filters,
                  sort: e.target.value as NonNullable<ProductFilters['sort']>,
                })
              }
            >
              <option value="name-asc">Nombre · A–Z</option>
              <option value="name-desc">Nombre · Z–A</option>
              <option value="sku-asc">Código interno</option>
              <option value="price-asc">Precio · Menor primero</option>
              <option value="price-desc">Precio · Mayor primero</option>
            </select>
          </label>
          <label className="field">
            Por página
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
            >
              <option value={10}>10 productos</option>
              <option value={25}>25 productos</option>
              <option value={50}>50 productos</option>
            </select>
          </label>
          <button className="button secondary" onClick={clearFilters}>
            Limpiar filtros
          </button>
        </div>
        {savedName && (
          <div className="inventory-saved" role="status">
            <span>
              <strong>Producto guardado: {savedName}.</strong> Mostrando el artículo actualizado.
            </span>
            <button className="button secondary" onClick={clearFilters}>
              Ver todo el inventario
            </button>
          </div>
        )}
        {query.isFetching && (
          <p className="inventory-loading" role="status">
            Actualizando resultados…
          </p>
        )}
        <Feedback error={query.error} />
        {query.isPending ? (
          <p className="empty-state">Cargando catálogo…</p>
        ) : (
          query.data && (
            <>
              <div className="table-scroll">
                <table role="table" className="products-table">
                  <thead role="rowgroup">
                    <tr role="row">
                      <th role="columnheader" scope="col">
                        Artículo / Código interno
                      </th>
                      <th role="columnheader" scope="col" className="numeric">
                        Venta unitaria
                      </th>
                      <th role="columnheader" scope="col" className="numeric">
                        Costo unitario
                      </th>
                      <th role="columnheader" scope="col" className="numeric">
                        Utilidad / Margen
                      </th>
                      <th role="columnheader" scope="col" className="numeric">
                        Menudeo
                      </th>
                      <th role="columnheader" scope="col" className="numeric">
                        Pedidos
                      </th>
                      <th role="columnheader" scope="col" className="product-actions-heading">
                        Gestión
                      </th>
                    </tr>
                  </thead>
                  <tbody role="rowgroup">
                    {query.data.items.map((p) => {
                      const profit = p.priceCents - p.costCents;
                      return (
                        <tr role="row" key={p.id}>
                          <td role="cell" data-label="Artículo / Código interno">
                            <div className="product-identity">
                              <span className="product-symbol">
                                <Package size={19} />
                              </span>
                              <div>
                                <strong>{p.name}</strong>
                                <small>{p.sku}</small>
                              </div>
                            </div>
                          </td>
                          <td
                            role="cell"
                            data-label="Venta unitaria"
                            className="numeric product-price"
                          >
                            {money(p.priceCents)}
                          </td>
                          <td
                            role="cell"
                            data-label="Costo unitario"
                            className="numeric product-cost"
                          >
                            {money(p.costCents)}
                          </td>
                          <td
                            role="cell"
                            data-label="Utilidad / Margen"
                            className={`numeric product-profit ${profit < 0 ? 'negative' : ''}`}
                          >
                            <strong>{money(profit)}</strong>
                            <small>
                              {p.priceCents > 0
                                ? `${((profit / p.priceCents) * 100).toFixed(1)} % sobre venta`
                                : 'Sin base de margen'}
                            </small>
                          </td>
                          <td role="cell" data-label="Menudeo" className="numeric product-stock">
                            <span
                              className={`stock-value ${p.retailStock === 0 ? 'is-empty' : ''}`}
                            >
                              {p.retailStock.toLocaleString('es-PE')}
                            </span>
                          </td>
                          <td role="cell" data-label="Pedidos" className="numeric product-stock">
                            <span
                              className={`stock-value ${p.ordersStock === 0 ? 'is-empty' : ''}`}
                            >
                              {p.ordersStock.toLocaleString('es-PE')}
                            </span>
                          </td>
                          <td role="cell" data-label="Gestión">
                            <div className="row-actions product-actions">
                              <button
                                className="button secondary"
                                aria-label={`Editar ${p.name}`}
                                onClick={() => {
                                  setEditor(p);
                                  setStock(null);
                                }}
                              >
                                <Pencil size={15} />
                                Editar
                              </button>
                              <button
                                className="button secondary"
                                aria-label={`Ajustar stock de ${p.name}`}
                                onClick={() => {
                                  setStock(p);
                                  setEditor(null);
                                }}
                              >
                                <SlidersHorizontal size={15} />
                                Stock
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {!query.data.items.length && (
                <div className="empty-state">
                  <Package size={28} />
                  <p>
                    {search.trim() || Object.keys(filters).length
                      ? 'No hay productos que coincidan con estos filtros. Prueba limpiarlos.'
                      : 'Registra tu primer producto para comenzar.'}
                  </p>
                </div>
              )}
              <div className="products-pagination">
                <Pagination {...query.data} onChange={setPage} />
              </div>
            </>
          )
        )}
      </section>
    </div>
  );
}
