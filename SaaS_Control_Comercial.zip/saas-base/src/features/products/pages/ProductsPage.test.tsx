import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, expect, it, vi } from 'vitest';
import { Component } from './ProductsPage';
const { query } = vi.hoisted(() => ({ query: vi.fn() }));
vi.mock('../hooks/useProducts', () => ({
  useProducts: (...args: unknown[]) => {
    query(...args);
    return {
      data: {
        items: [
          {
            id: 'product-1',
            name: 'Guantes',
            sku: 'PRD-000001',
            priceCents: 1500,
            costCents: 1000,
            retailStock: 4,
            ordersStock: 0,
            active: true,
          },
        ],
        total: 70,
        page: args[1],
        pageSize: args[3],
      },
      isPending: false,
      isFetching: false,
      error: null,
    };
  },
}));
vi.mock('../components/ProductEditor', () => ({
  ProductEditor: ({
    onSaved,
    onDone,
  }: {
    onSaved: (saved: { id: string; name: string }) => void;
    onDone: () => void;
  }) => (
    <div>
      <button
        onClick={() => {
          onSaved({ id: 'product-1', name: 'Zapatos' });
          onDone();
        }}
      >
        Guardar prueba
      </button>
      <button onClick={onDone}>Cancelar prueba</button>
    </div>
  ),
}));
afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});
it('locates a renamed product by identity instead of retaining the old search or page', () => {
  render(<Component />);
  fireEvent.change(screen.getByLabelText('Buscar por código o artículo'), {
    target: { value: 'Guantes' },
  });
  fireEvent.change(screen.getByLabelText('Existencias'), { target: { value: 'retail-positive' } });
  fireEvent.click(screen.getByRole('button', { name: 'Siguiente' }));
  fireEvent.click(screen.getByRole('button', { name: 'Editar Guantes' }));
  fireEvent.click(screen.getByText('Guardar prueba'));
  expect(query.mock.lastCall).toEqual(['', 1, false, 25, true, { productId: 'product-1' }]);
  expect(screen.getByText(/Producto guardado: Zapatos/)).toBeInTheDocument();
  fireEvent.click(screen.getByText('Ver todo el inventario'));
  expect(query.mock.lastCall?.[5]).toEqual({});
});
it('keeps the current filters and page when cancelling and resets page on filter changes', () => {
  render(<Component />);
  fireEvent.change(screen.getByLabelText('Existencias'), { target: { value: 'orders-zero' } });
  fireEvent.click(screen.getByRole('button', { name: 'Siguiente' }));
  fireEvent.click(screen.getByRole('button', { name: 'Editar Guantes' }));
  fireEvent.click(screen.getByText('Cancelar prueba'));
  expect(query.mock.lastCall?.[1]).toBe(2);
  expect(query.mock.lastCall?.[5]).toEqual({ stock: 'orders-zero' });
  fireEvent.change(screen.getByLabelText('Ordenar por'), { target: { value: 'price-desc' } });
  expect(query.mock.lastCall?.[1]).toBe(1);
});
