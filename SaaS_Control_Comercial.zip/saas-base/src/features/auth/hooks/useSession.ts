import { useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/shared/supabase/client';
import { authApi } from '../api/auth.api';
export function useSession() {
  const client = useQueryClient();
  const query = useQuery({
    queryKey: ['session'],
    queryFn: authApi.session,
    retry: false,
    staleTime: 60000,
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange(() => {
      window.setTimeout(() => void client.invalidateQueries({ queryKey: ['session'] }), 0);
    });
    return () => data.subscription.unsubscribe();
  }, [client]);

  return query;
}
export function useTenantId() {
  return useSession().data?.tenantId ?? 'anonymous';
}
