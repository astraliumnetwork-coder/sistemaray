import { beforeEach, describe, expect, it, vi } from 'vitest';
import { credentialsSchema, registrationSchema } from '@saas/domain';
const mocks = vi.hoisted(() => ({
  getSession: vi.fn(),
  signInWithPassword: vi.fn(),
  signInAnonymously: vi.fn(),
  from: vi.fn(),
}));
vi.mock('@/shared/supabase/client', () => ({ supabase: { auth: mocks, from: mocks.from } }));
import { authApi } from './auth.api';
beforeEach(() => vi.resetAllMocks());
describe('Shared account access', () => {
  it('does not create identities or companies when no session exists', async () => {
    mocks.getSession.mockResolvedValue({ data: { session: null }, error: null });
    expect(await authApi.session()).toBeNull();
    expect(mocks.signInAnonymously).not.toHaveBeenCalled();
    expect(mocks.from).not.toHaveBeenCalled();
  });
  it('requires login instead of retaining the anonymous workspace', async () => {
    mocks.getSession.mockResolvedValue({
      data: { session: { user: { id: 'old', is_anonymous: true } } },
      error: null,
    });
    expect(await authApi.session()).toBeNull();
    expect(mocks.from).not.toHaveBeenCalled();
  });
  it('uses the server profile tenant after authenticating', async () => {
    const userId = '00000000-0000-4000-8000-000000000001';
    const tenantId = '00000000-0000-4000-8000-000000000002';
    mocks.signInWithPassword.mockResolvedValue({ error: null });
    mocks.getSession.mockResolvedValue({
      data: { session: { user: { id: userId, email: 'admin@sistema.com', is_anonymous: false } } },
      error: null,
    });
    const eq = vi.fn().mockReturnValue({
      single: vi.fn().mockResolvedValue({ data: { tenant_id: tenantId }, error: null }),
    });
    mocks.from.mockImplementation((table: string) =>
      table === 'users'
        ? { select: () => ({ eq }) }
        : {
            select: () => ({
              eq: () => ({
                single: async () => ({ data: { name: 'Empresa existente' }, error: null }),
              }),
            }),
          },
    );
    const result = await authApi.login({ email: 'admin@sistema.com', password: 'admin123' });
    expect(mocks.signInWithPassword).toHaveBeenCalledWith({
      email: 'admin@sistema.com',
      password: 'admin123',
    });
    expect(eq).toHaveBeenCalledWith('id', userId);
    expect(result?.tenantId).toBe(tenantId);
  });
  it('passes the requested password to Auth without weakening new-company registration', () => {
    expect(
      credentialsSchema.safeParse({ email: 'admin@sistema.com', password: 'admin123' }).success,
    ).toBe(true);
    expect(
      registrationSchema.safeParse({
        email: 'admin@sistema.com',
        password: 'admin123',
        organizationName: 'Empresa',
      }).success,
    ).toBe(false);
  });
  it('rejects incorrect credentials without an anonymous fallback', async () => {
    mocks.signInWithPassword.mockResolvedValue({ error: new Error('Invalid login credentials') });
    await expect(
      authApi.login({ email: 'admin@sistema.com', password: 'incorrecta' }),
    ).rejects.toThrow('Invalid login credentials');
    expect(mocks.getSession).not.toHaveBeenCalled();
    expect(mocks.signInAnonymously).not.toHaveBeenCalled();
  });
});
