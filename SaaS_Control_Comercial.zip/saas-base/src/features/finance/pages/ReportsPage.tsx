import { useState } from 'react';
import { channelLabels, localDate, money, paymentLabels } from '@saas/domain';
import type { Channel } from '@saas/domain';
import { useReport } from '../hooks/useFinance';
import { currentWeek } from '../model/period';
import { ResultCards } from '../components/ResultCards';
import { Feedback } from '@/shared/ui/Feedback';
export function Component() {
  const [period, setPeriod] = useState({ from: localDate(), to: localDate() });
  const [channel, setChannel] = useState<Channel | 'all'>('all');
  const query = useReport(period.from, period.to, channel);
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">RESULTADOS</p>
          <h1>Ganancias y pérdidas</h1>
          <p className="muted">Resultado operativo simplificado · PEN · Fechas de Lima.</p>
        </div>
        <button
          className="button secondary"
          disabled={query.isFetching}
          onClick={() => void query.refetch()}
        >
          Actualizar
        </button>
      </div>
      <section className="panel filter-bar">
        <button
          className="button secondary"
          onClick={() => setPeriod({ from: localDate(), to: localDate() })}
        >
          Hoy
        </button>
        <button className="button secondary" onClick={() => setPeriod(currentWeek())}>
          Esta semana
        </button>
        <div className="field">
          <label htmlFor="from">Desde</label>
          <input
            id="from"
            type="date"
            value={period.from}
            onChange={(e) => setPeriod({ ...period, from: e.target.value })}
          />
        </div>
        <div className="field">
          <label htmlFor="to">Hasta</label>
          <input
            id="to"
            type="date"
            value={period.to}
            onChange={(e) => setPeriod({ ...period, to: e.target.value })}
          />
        </div>
        <div className="field">
          <label htmlFor="report-channel">Línea de negocio</label>
          <select
            id="report-channel"
            value={channel}
            onChange={(e) => setChannel(e.target.value as Channel | 'all')}
          >
            <option value="all">Consolidado</option>
            <option value="retail">Menudeo</option>
            <option value="orders">Pedidos</option>
          </select>
        </div>
      </section>
      {period.from > period.to && (
        <p role="alert" className="field-error">
          La fecha inicial no puede superar la final.
        </p>
      )}
      <Feedback error={query.error} />
      {query.isPending && query.fetchStatus === 'fetching' && <p>Cargando resultados…</p>}
      {query.data && (
        <>
          <ResultCards data={query.data} />
          <section className="panel">
            <div className="section-heading">
              <h2>Resumen diario</h2>
              <span className="badge">{query.data.transactions} operaciones contabilizadas</span>
            </div>
            <div className="table-scroll">
              <table role="table">
                <thead role="rowgroup">
                  <tr role="row">
                    <th role="columnheader" scope="col">
                      Fecha
                    </th>
                    <th role="columnheader" scope="col">
                      Ventas
                    </th>
                    <th role="columnheader" scope="col">
                      Costo
                    </th>
                    <th role="columnheader" scope="col">
                      Utilidad bruta
                    </th>
                    <th role="columnheader" scope="col">
                      Gastos
                    </th>
                    <th role="columnheader" scope="col">
                      Resultado operativo
                    </th>
                  </tr>
                </thead>
                <tbody role="rowgroup">
                  {query.data.daily.map((d) => (
                    <tr role="row" key={d.date}>
                      <td role="cell" data-label="Fecha">
                        {d.date}
                      </td>
                      <td role="cell" data-label="Ventas">
                        {money(d.salesCents)}
                      </td>
                      <td role="cell" data-label="Costo">
                        {money(d.costTotalCents)}
                      </td>
                      <td role="cell" data-label="Utilidad bruta">
                        {money(d.grossCents)}
                      </td>
                      <td role="cell" data-label="Gastos">
                        {money(d.expensesCents)}
                      </td>
                      <td
                        role="cell"
                        data-label="Resultado operativo"
                        className={d.netCents < 0 ? 'negative' : ''}
                      >
                        {money(d.netCents)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
          <section className="panel">
            <h2>Ventas por método de pago</h2>
            <ul className="readiness-list">
              {query.data.byPayment.map((p) => (
                <li key={p.payment}>
                  <span>{paymentLabels[p.payment]}</span>
                  <strong>{money(p.salesCents)}</strong>
                </li>
              ))}
            </ul>
            {!query.data.byPayment.length && (
              <p className="empty-state">Sin ventas contabilizadas en este período.</p>
            )}
            <p className="notice">
              {channel === 'all' ? 'Ambas líneas' : channelLabels[channel]} · Los pedidos pendientes
              no cuentan como ingresos. El método corresponde al indicado en la venta; este reporte
              no es una conciliación bancaria ni gestiona cuentas por cobrar. No incluye impuestos,
              depreciación ni ajustes contables.
            </p>
          </section>
        </>
      )}
    </div>
  );
}
