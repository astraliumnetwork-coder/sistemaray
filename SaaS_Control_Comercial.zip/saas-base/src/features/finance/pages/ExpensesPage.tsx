import { errorMessage } from '@/shared/lib/error-message';
import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { channelLabels, expenseInput, localDate, money, parseMoney } from '@saas/domain';
import { useExpenses, useExpenseAction } from '../hooks/useFinance';
import { Modal } from '@/shared/ui/Modal';
import { Feedback } from '@/shared/ui/Feedback';
import { Pagination } from '@/shared/ui/Pagination';
export function Component() {
  const [open, setOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [error, setError] = useState('');
  const query = useExpenses(page);
  const action = useExpenseAction();
  const key = useRef(crypto.randomUUID());
  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    try {
      const input = expenseInput.parse({
        description: data.get('description'),
        amountCents: parseMoney(String(data.get('amount'))),
        channel: data.get('channel'),
        spentOn: data.get('spentOn'),
      });
      setError('');
      action.mutate(
        { input, key: key.current },
        {
          onSuccess: () => {
            form.reset();
            key.current = crypto.randomUUID();
            setPage(1);
            setOpen(false);
          },
        },
      );
    } catch (err) {
      setError(errorMessage(err));
    }
  }
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <p className="eyebrow">CONTROL FINANCIERO</p>
          <h1>Gastos operativos</h1>
          <p className="muted">
            Registra gastos por línea para calcular el resultado después de gastos.
          </p>
        </div>
        <button
          className="button primary"
          onClick={() => {
            setError('');
            action.reset();
            key.current = crypto.randomUUID();
            setOpen(true);
          }}
        >
          Nuevo gasto
        </button>
      </div>
      {open && (
        <Modal
          title="Registrar gasto operativo"
          onClose={() => setOpen(false)}
          busy={action.isPending}
        >
          <form
            className="settings-form"
            onSubmit={submit}
            onChange={() => {
              key.current = crypto.randomUUID();
              action.reset();
            }}
          >
            <fieldset disabled={action.isPending}>
              <div className="form-grid">
                <div className="field">
                  <label htmlFor="expense-description">Descripción</label>
                  <input
                    id="expense-description"
                    name="description"
                    required
                    minLength={2}
                    maxLength={160}
                  />
                </div>
                <div className="field">
                  <label htmlFor="expense-amount">Importe (S/)</label>
                  <input
                    id="expense-amount"
                    name="amount"
                    type="number"
                    min="0.01"
                    max="1000000"
                    step="0.01"
                    required
                  />
                </div>
                <div className="field">
                  <label htmlFor="expense-date">Fecha del gasto</label>
                  <input
                    id="expense-date"
                    name="spentOn"
                    type="date"
                    defaultValue={localDate()}
                    required
                  />
                </div>
                <div className="field">
                  <label htmlFor="expense-channel">Línea de negocio</label>
                  <select id="expense-channel" name="channel">
                    <option value="retail">Menudeo</option>
                    <option value="orders">Pedidos</option>
                  </select>
                </div>
              </div>
              <div className="modal-actions">
                <button className="button secondary" type="button" onClick={() => setOpen(false)}>
                  Cancelar
                </button>
                <button className="button primary">
                  {action.isPending ? 'Guardando…' : 'Registrar gasto'}
                </button>
              </div>
            </fieldset>
            <Feedback error={error || action.error} />
          </form>
        </Modal>
      )}
      {action.isSuccess && <p role="status">Gasto registrado.</p>}
      <section className="panel">
        <h2>Gastos registrados</h2>
        <Feedback error={query.error} />
        {query.isPending ? (
          <p>Cargando…</p>
        ) : (
          query.data && (
            <>
              <div className="table-scroll">
                <table role="table">
                  <thead role="rowgroup">
                    <tr role="row">
                      <th role="columnheader" scope="col">
                        Fecha
                      </th>
                      <th role="columnheader" scope="col">
                        Descripción
                      </th>
                      <th role="columnheader" scope="col">
                        Línea
                      </th>
                      <th role="columnheader" scope="col">
                        Importe
                      </th>
                    </tr>
                  </thead>
                  <tbody role="rowgroup">
                    {query.data.items.map((e) => (
                      <tr role="row" key={e.id}>
                        <td role="cell" data-label="Fecha">
                          {e.spentOn}
                        </td>
                        <td role="cell" data-label="Descripción">
                          {e.description}
                        </td>
                        <td role="cell" data-label="Línea">
                          {channelLabels[e.channel]}
                        </td>
                        <td role="cell" data-label="Importe">
                          {money(e.amountCents)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {!query.data.items.length && (
                <p className="empty-state">Todavía no hay gastos registrados.</p>
              )}
              <Pagination {...query.data} onChange={setPage} />
            </>
          )
        )}
      </section>
    </div>
  );
}
