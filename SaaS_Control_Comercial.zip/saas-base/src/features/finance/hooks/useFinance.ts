import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { Channel } from '@saas/domain';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { financeApi } from '../api/finance.api';
export function useReport(from: string, to: string, channel: Channel | 'all' = 'all') {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'report', from, to, channel],
    enabled: !!from && !!to && from <= to,
    queryFn: ({ signal }) => financeApi.report(from, to, channel, signal),
  });
}
export function useExpenses(page: number) {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'expenses', page],
    queryFn: ({ signal }) => financeApi.expenses(page, signal),
  });
}
export function useExpenseAction() {
  const client = useQueryClient();
  const tenant = useTenantId();
  return useMutation({
    mutationFn: ({ input, key }: { input: unknown; key: string }) =>
      financeApi.createExpense(input, key),
    onSuccess: () => client.invalidateQueries({ queryKey: [tenant] }),
  });
}
