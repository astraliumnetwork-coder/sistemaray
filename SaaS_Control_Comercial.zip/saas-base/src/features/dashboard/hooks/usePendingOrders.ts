import { useQuery } from '@tanstack/react-query';
import { useTenantId } from '@/features/auth/hooks/useSession';
import { dashboardApi } from '../api/dashboard.api';
export function usePendingOrders() {
  const tenant = useTenantId();
  return useQuery({
    queryKey: [tenant, 'dashboard', 'pending-orders'],
    queryFn: ({ signal }) => dashboardApi.pendingOrders(signal),
  });
}
