import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  Banknote,
  CalendarDays,
  CheckCheck,
  ClipboardList,
  Package,
  Plus,
  Receipt,
  RefreshCw,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import { localDate, money } from '@saas/domain';
import { useReport } from '@/features/finance/hooks/useFinance';
import { currentWeek } from '@/features/finance/model/period';
import { SaleDetail } from '@/features/transactions/components/SaleDetail';
import { Feedback } from '@/shared/ui/Feedback';
import { PaymentChart, ProfitBreakdown, SalesTrend } from '../components/BusinessCharts';
import { usePendingOrders } from '../hooks/usePendingOrders';

export function Component() {
  const today = localDate();
  const week = currentWeek();
  const daily = useReport(today, today);
  const weekly = useReport(week.from, week.to);
  const orders = usePendingOrders();
  const [detail, setDetail] = useState<string | null>(null);
  const busy = daily.isFetching || weekly.isFetching || orders.isFetching;
  const dayLabel = new Intl.DateTimeFormat('es-PE', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    timeZone: 'America/Lima',
  }).format(new Date(`${today}T12:00:00Z`));
  const metrics = [
    {
      label: 'Ventas de hoy',
      value: daily.data?.salesCents,
      icon: Banknote,
      note: daily.data
        ? `${daily.data.transactions} operaciones contabilizadas`
        : 'Consultando ventas',
    },
    {
      label: 'Utilidad bruta',
      value: daily.data?.grossCents,
      icon: TrendingUp,
      note: daily.data
        ? `Mercadería: ${money(daily.data.costTotalCents)}`
        : 'Ventas menos mercadería',
    },
    {
      label: 'Gastos de hoy',
      value: daily.data?.expensesCents,
      icon: Receipt,
      note: 'Gastos operativos registrados',
    },
    {
      label: 'Resultado de hoy',
      value: daily.data?.netCents,
      icon: Wallet,
      note: 'Después de mercadería y gastos',
    },
  ];
  return (
    <div className="page ops-page">
      <header className="ops-header">
        <div>
          <p className="eyebrow">CONTROL COMERCIAL</p>
          <h1>Centro de operaciones</h1>
          <p className="ops-date">
            <CalendarDays size={14} />
            {dayLabel} · Lima
          </p>
        </div>
        <div className="ops-header-actions">
          <button
            type="button"
            className="button secondary"
            disabled={busy}
            onClick={() => {
              void daily.refetch();
              void weekly.refetch();
              void orders.refetch();
            }}
          >
            <RefreshCw size={15} />
            {busy ? 'Actualizando…' : 'Actualizar'}
          </button>
          <Link className="button primary" to="/menudeo?nueva=1">
            <Plus size={17} />
            Registrar venta
          </Link>
        </div>
      </header>
      <Feedback error={daily.error || weekly.error || orders.error} />
      <nav className="ops-actions" aria-label="Acciones de operación">
        <Link to="/pedidos?nueva=1">
          <ClipboardList size={19} />
          <span>
            Nuevo pedido<small>Programar una entrega</small>
          </span>
          <ArrowUpRight size={15} />
        </Link>
        <Link to="/productos">
          <Package size={19} />
          <span>
            Productos e inventario<small>Precios y existencias</small>
          </span>
          <ArrowUpRight size={15} />
        </Link>
        <Link to="/gastos">
          <Receipt size={19} />
          <span>
            Gestionar gastos<small>Controlar egresos</small>
          </span>
          <ArrowUpRight size={15} />
        </Link>
        <Link to="/reportes">
          <TrendingUp size={19} />
          <span>
            Ganancias y pérdidas<small>Consultar resultados</small>
          </span>
          <ArrowUpRight size={15} />
        </Link>
      </nav>
      <section className="ops-kpis" aria-label="Resultados de hoy">
        {metrics.map(({ label, value, icon: Icon, note }, index) => (
          <article key={label} className={index === 3 ? 'ops-kpi-result' : ''}>
            <div>
              <span>{label}</span>
              <Icon size={17} />
            </div>
            <strong className={value != null && value < 0 ? 'negative' : ''}>
              {value != null ? money(value) : '—'}
            </strong>
            <small>{note}</small>
          </article>
        ))}
      </section>
      <div className="ops-grid">
        <div className="ops-column">
          {weekly.data ? (
            <SalesTrend report={weekly.data} from={week.from} to={week.to} />
          ) : (
            <section className="ops-panel ops-load" role="status">
              {weekly.error ? 'No se pudo cargar el resumen semanal.' : 'Cargando resumen semanal…'}
            </section>
          )}
          <section className="ops-panel ops-orders" aria-labelledby="pending-title">
            <div className="ops-panel-heading">
              <div>
                <h2 id="pending-title">
                  Pedidos por atender <span className="ops-count">{orders.data?.total ?? '—'}</span>
                </h2>
                <p>Prioridad por fecha de entrega</p>
              </div>
              <Link to="/pedidos" className="ops-inline-link">
                Ver pedidos <ArrowUpRight size={14} />
              </Link>
            </div>
            {orders.data ? (
              orders.data.items.length > 0 ? (
                <ul className="ops-order-list">
                  {orders.data.items.map((order) => {
                    const late = !!order.scheduled_for && order.scheduled_for < today;
                    const due = order.scheduled_for === today;
                    return (
                      <li key={order.id}>
                        <span className={`ops-order-icon ${late ? 'is-late' : ''}`}>
                          <ClipboardList size={18} />
                        </span>
                        <div>
                          <strong>{order.customer || 'Sin cliente'}</strong>
                          <small>
                            {order.scheduled_for
                              ? `Entrega: ${order.scheduled_for.split('-').reverse().join('/')}`
                              : 'Sin fecha de entrega'}
                          </small>
                        </div>
                        <span className={`ops-order-status ${late ? 'is-late' : ''}`}>
                          {late ? 'Atrasado' : due ? 'Hoy' : 'Pendiente'}
                        </span>
                        <button
                          type="button"
                          onClick={() => setDetail(order.id)}
                          aria-label={`Ver pedido de ${order.customer || 'Sin cliente'}`}
                        >
                          Ver <ArrowUpRight size={14} />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <div className="ops-empty ops-orders-empty">
                  <CheckCheck size={25} />
                  <div>
                    <strong>No tienes pedidos pendientes</strong>
                    <p>Los próximos pedidos aparecerán aquí para darles seguimiento.</p>
                  </div>
                </div>
              )
            ) : (
              <p className="ops-panel-note" role="status">
                {orders.error ? 'No se pudieron cargar los pedidos.' : 'Consultando pedidos…'}
              </p>
            )}
            {!!orders.data?.items.length && (
              <div className="ops-panel-note">
                Mostrando {orders.data.items.length} de {orders.data.total} pendientes. Abrir un
                pedido no modifica su estado.
              </div>
            )}
          </section>
        </div>
        <div className="ops-column">
          {daily.data ? (
            <PaymentChart report={daily.data} />
          ) : (
            <section className="ops-panel ops-load" role="status">
              {daily.error ? 'No se pudieron cargar los pagos.' : 'Cargando medios de pago…'}
            </section>
          )}
          {weekly.data && <ProfitBreakdown report={weekly.data} />}
        </div>
      </div>
      {detail && <SaleDetail id={detail} onClose={() => setDetail(null)} />}
    </div>
  );
}
