import { useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, ArrowUpRight, Wallet } from 'lucide-react';
import { money, paymentLabels, type Report } from '@saas/domain';

export function SalesTrend({ report, from, to }: { report: Report; from: string; to: string }) {
  const [selected, setSelected] = useState<string>();
  const days: { date: string; value: number }[] = [];
  for (
    const date = new Date(`${from}T12:00:00Z`);
    date.toISOString().slice(0, 10) <= to;
    date.setUTCDate(date.getUTCDate() + 1)
  ) {
    const iso = date.toISOString().slice(0, 10);
    days.push({
      date: iso,
      value: report.daily.find((entry) => entry.date === iso)?.salesCents ?? 0,
    });
  }
  const max = Math.max(1, ...days.map((day) => day.value));
  const active = days.find((day) => day.date === selected) ?? days.at(-1);
  const shortDate = (date: string) =>
    new Intl.DateTimeFormat('es-PE', {
      weekday: 'short',
      day: 'numeric',
      timeZone: 'America/Lima',
    }).format(new Date(`${date}T12:00:00Z`));
  return (
    <section className="ops-panel ops-trend" aria-labelledby="trend-title">
      <div className="ops-panel-heading">
        <div>
          <h2 id="trend-title">Ventas de la semana</h2>
          <p>
            Del {from.slice(8)} al {to.slice(8)} ·{' '}
            {new Intl.DateTimeFormat('es-PE', { month: 'long', timeZone: 'America/Lima' }).format(
              new Date(`${to}T12:00:00Z`),
            )}
          </p>
        </div>
        <Link to="/reportes" className="ops-inline-link">
          Ver reporte <ArrowUpRight size={14} />
        </Link>
      </div>
      <div className="ops-trend-total">
        <strong>{money(report.salesCents)}</strong>
        <span>{report.transactions} operaciones contabilizadas</span>
      </div>
      {report.transactions > 0 ? (
        <>
          <div className="ops-bar-chart" aria-label="Ventas por día">
            {days.map((day) => (
              <button
                key={day.date}
                type="button"
                aria-pressed={day.date === active?.date}
                aria-label={`${shortDate(day.date)}: ${money(day.value)}`}
                onClick={() => setSelected(day.date)}
                title={`${shortDate(day.date)} · ${money(day.value)}`}
              >
                <span className="ops-bar-space">
                  <span className="ops-bar" style={{ height: `${(day.value / max) * 100}%` }} />
                </span>
                <span className="ops-bar-label">{shortDate(day.date)}</span>
              </button>
            ))}
          </div>
          <div className="ops-chart-caption" aria-live="polite">
            <span>{active ? shortDate(active.date) : '—'}</span>
            <strong>{active ? money(active.value) : '—'}</strong>
            <small>Selecciona una barra</small>
          </div>
        </>
      ) : (
        <div className="ops-empty">
          <BarChart3 size={24} />
          <div>
            <strong>Aún no hay ventas esta semana</strong>
            <p>La evolución aparecerá al registrar tu primera venta.</p>
          </div>
          <Link to="/menudeo?nueva=1">
            Registrar venta <ArrowUpRight size={14} />
          </Link>
        </div>
      )}
      <div className="ops-chart-footer">
        <span>
          Ticket promedio{' '}
          <b>
            {report.transactions > 0
              ? money(Math.round(report.salesCents / report.transactions))
              : '—'}
          </b>
        </span>
        <span>
          Utilidad bruta{' '}
          <b className={report.grossCents < 0 ? 'negative' : ''}>{money(report.grossCents)}</b>
        </span>
        <span>
          Margen bruto{' '}
          <b>
            {report.salesCents > 0
              ? `${((report.grossCents / report.salesCents) * 100).toLocaleString('es-PE', { maximumFractionDigits: 1 })}%`
              : '—'}
          </b>
        </span>
      </div>
    </section>
  );
}

export function PaymentChart({ report }: { report: Report }) {
  const total = report.byPayment.reduce((sum, row) => sum + row.salesCents, 0);
  const payments = Object.entries(paymentLabels).map(([key, label]) => ({
    key,
    label,
    value: report.byPayment.find((row) => row.payment === key)?.salesCents ?? 0,
  }));
  return (
    <section className="ops-panel" aria-labelledby="payment-title">
      <div className="ops-panel-heading">
        <div>
          <h2 id="payment-title">Ventas por medio de pago</h2>
          <p>Distribución de hoy</p>
        </div>
        <Wallet size={19} className="ops-muted-icon" />
      </div>
      {total > 0 ? (
        <ul className="ops-payment-chart">
          {payments.map(({ key, label, value }) => (
            <li key={key}>
              <div>
                <span>{label}</span>
                <strong>{money(value)}</strong>
                <small>{Math.round((value / total) * 100)}%</small>
              </div>
              <div className="ops-track" aria-hidden="true">
                <span style={{ width: `${(value / total) * 100}%` }} />
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="ops-empty">
          <Wallet size={24} />
          <div>
            <strong>Sin ventas registradas hoy</strong>
            <p>Efectivo, Yape, Plin y transferencias se mostrarán aquí.</p>
          </div>
        </div>
      )}
      <div className="ops-panel-note">
        Solo ventas contabilizadas. Los pedidos se incluyen al entregar.
      </div>
    </section>
  );
}

export function ProfitBreakdown({ report }: { report: Report }) {
  const rows = [
    { label: 'Mercadería vendida', value: report.costTotalCents, color: 'cost' },
    { label: 'Gastos operativos', value: report.expensesCents, color: 'expense' },
    {
      label: 'Resultado neto',
      value: report.netCents,
      color: report.netCents < 0 ? 'loss' : 'profit',
    },
  ];
  const max = Math.max(1, report.salesCents, ...rows.map((row) => Math.abs(row.value)));
  return (
    <section className="ops-panel" aria-labelledby="profit-title">
      <div className="ops-panel-heading">
        <div>
          <h2 id="profit-title">¿Qué queda de tus ventas?</h2>
          <p>Desglose de la semana</p>
        </div>
      </div>
      <div className="ops-profit-base">
        <span>Ventas registradas</span>
        <strong>{money(report.salesCents)}</strong>
      </div>
      <ul className="ops-profit-chart">
        {rows.map((row) => (
          <li key={row.label}>
            <div>
              <span>{row.label}</span>
              <strong className={row.value < 0 ? 'negative' : ''}>{money(row.value)}</strong>
            </div>
            <div className={`ops-track ${row.color}`} aria-hidden="true">
              <span style={{ width: `${(Math.abs(row.value) / max) * 100}%` }} />
            </div>
          </li>
        ))}
      </ul>
      <p className={`ops-profit-status ${report.netCents < 0 ? 'is-loss' : ''}`}>
        {report.transactions === 0 && report.expensesCents === 0
          ? 'Registra ventas y gastos para evaluar tu resultado.'
          : report.netCents < 0
            ? `Faltan ${money(-report.netCents)} para cubrir mercadería y gastos.`
            : report.netCents === 0
              ? 'Las ventas cubren exactamente mercadería y gastos.'
              : `Quedan ${money(report.netCents)} después de mercadería y gastos.`}
      </p>
    </section>
  );
}
