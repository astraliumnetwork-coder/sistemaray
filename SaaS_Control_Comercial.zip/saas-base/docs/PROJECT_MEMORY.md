# Memoria técnica · Control Comercial

Actualizada: 2026-10-21. Versión: 0.3.0. Entrega canónica: `SaaS_Control_Comercial.zip`.

## Punto de continuidad

Leer este archivo, `AGENTS.md`, `docs/REQUISITOS.md` y el módulo afectado antes de continuar. Aplicar `arquitecto-saas-erp` y `entregar-codigo-completo`. La entrega vigente y este archivo son la fuente de verdad; actualizar la memoria y el ZIP al cerrar cada sesión.

## Objetivo y requisitos

Migrar el control comercial manual a una herramienta de ventas, inventario y resultados. React + TypeScript solicitado por Farid. Prioridades: orden, modularidad, velocidad y facilidad de corrección.

Requisitos del MD: fecha automática, producto, cantidad, precio/costo, totales y utilidad; resultados diarios/semanales; ventas de menudeo y pedidos separados; método de pago; dashboard y catálogo.

Excel recibido: `VENTAS SANDIA (1).xlsx`, auditado en `docs/excel/LEEME.md`. Son 630 líneas numéricas (624 con artículo y 6 sin descripción), no tickets identificados. Venta original S/ 32,259.50; costo original S/ 24,267.40; utilidad de ventas S/ 7,992.10. La cifra S/ 8,417.10 agrega S/ 425 de tres celdas de cierre sin contexto. Fila 590: diferencia de costo S/ 4; utilidad recalculada global S/ 7,996.10. No se migraron ventas históricas a Supabase.

## Arquitectura vigente

- React 19 + TypeScript + Vite en cliente; React Router, TanStack Query, Zod y Lucide.
- Supabase JS directo desde el cliente con Auth y Postgres/PostgREST/RPC. No existe API Express activa ni conexión `pg` en el flujo de desarrollo.
- `.env` raíz: `VITE_APP_NAME`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`. `.env.example` apunta al proyecto Supabase compartido y usa su clave publicable. La clave publicable puede estar en el navegador; nunca usar `service_role` en `VITE_*`.
- El ZIP entregado incluye `.env` (solo URL y clave publicable) para arrancar sin copiarlo manualmente. Si falta, `Copy-Item .env.example .env`. En Vite, usar prefijo `VITE_`, no `NEXT_PUBLIC_`.
- `supabase/schema.sql` crea tenant y perfil al registrar, tablas/índices, RLS y RPC transaccionales. Debe ejecutarse una sola vez desde Supabase SQL Editor en una base nueva. `supabase/temporary_access.sql` actualiza únicamente el trigger si el esquema ya estaba instalado.
- `packages/domain` conserva tipos Zod, cálculos en céntimos y fechas Lima. `src/features/*/api` actúa como repositorio Supabase por módulo; hooks React Query manejan cache/paginación.
- RLS obtiene `tenant_id` desde `auth.uid()` y `public.users`; las tablas mantienen relaciones compuestas por tenant. El cliente tiene permisos de lectura; los RPC de escritura `SECURITY DEFINER` tienen `search_path` vacío, derivan tenant/actor de Auth, no aceptan tenant del navegador y escriben de forma atómica.
- Sin Docker, PostgreSQL local, `DATABASE_URL`, `ADMIN_DATABASE_URL`, CA/TLS manual ni servidor API para iniciar. Comandos: `npm install`, copiar `.env.example` a `.env`, instalar `supabase/schema.sql` una vez, `npm run dev`.

## Sidebar empresarial

- Cabecera con imagen `public/logo.png` en lugar del título e icono. No se recibió el archivo de imagen: añadir el logo real en esa ruta. Se eliminó el rótulo inferior Control Comercial/v0.3.0.

- Sidebar negro con navegación gris, estado activo verde y foco de teclado visible. Empresa, inicial dinámica y acceso temporal se agrupan en el pie, sin texto de versión. Se conserva el menú compacto y la navegación móvil. Referencia visual: Sidebar(1).tsx; se adapta al stack React Router existente.

## Gestión de productos vigente

- Alta, edición y ajuste de stock en modal nativo `dialog`: foco confinado por navegador, Escape/cierre, devolución de foco y cierre bloqueado mientras guarda. El código es de solo lectura en edición y automático al crear.
- Tabla renovada: artículo/código, precio, costo, utilidad y margen sobre venta (sin porcentaje para precio cero), stock por canal y acciones con etiquetas. Columna Estado retirada por petición del usuario; se conserva la disponibilidad para nuevas ventas en la edición.
- Códigos internos `PRD-000001` generados por secuencia del servidor. `supabase/product_codes.sql` convierte EXCEL-* existentes sin cambiar UUID, relaciones, stock o importes; conserva códigos personalizados. La secuencia puede tener saltos y no reinicia por tenant. El schema nuevo incluye la migración.
- Botón y componente de carga Excel retirados por petición del usuario; RPC histórico sin permiso de ejecución para authenticated para evitar nuevas cargas tras cambiar códigos. Datos y auditoría del archivo se conservan como referencia histórica.

## Catálogo basado en el Excel recibido (etapa anterior, interfaz retirada)

- Productos → Catálogo del Excel: carga diferida de 337 referencias, búsqueda, selección y carga atómica vía `import_product_catalog`. Códigos basados en primera fila; precio y costo de última aparición en orden del archivo. Normaliza solo mayúsculas/espacios, sin fusionar alias o tallas.
- `supabase/excel_catalog.sql` es la migración incremental para bases existentes; `schema.sql` ya incluye la función para bases nuevas. Deriva tenant desde Auth, bloquea cargas concurrentes por tenant, omite códigos existentes y no cambia sus precios/stock. Stock inicial cero en ambos canales; revisar precios históricos de 2021 y conteo físico antes de vender.
- `scripts/audit_sales_excel.py` extrae el XLSX recibido sin modificarlo, produce catálogo TS y `docs/excel/{auditoria.json,ventas_normalizadas.csv}`. 44 líneas con fecha no resoluble y 622 sin pago explícito; canales/cuentas no identificados. CSV y auditoría no se sirven como datos globales de la app ni se cargan como operaciones.
- Pruebas añadidas: referencias válidas y conciliación de fuente; carga SQL, reintento, preservación de valores, stock cero, aislamiento entre tenants y rollback de lote inválido. La concurrencia real requiere varias conexiones Supabase.

## Funciones vigentes

- El contenido principal usa todo el ancho disponible junto al sidebar, sin el límite anterior de 1350 px. Márgenes internos: 32 px en escritorio, 24 px en tablet y 20 px en móvil; se conserva el comportamiento responsive.

1. Supabase Auth temporal sin login visible. La app crea una sesión anónima persistente; el trigger de `auth.users` crea tenant y perfil. El tenant queda ligado al almacenamiento del navegador.
2. Productos paginados/búsqueda, edición, stock inicial en ambos canales y ajustes auditados.
3. Stock independiente para `retail` y `orders`.
4. Venta de menudeo con varias líneas; guarda snapshots y deduce stock en el mismo RPC.
5. Pedido pendiente; no reserva stock; entrega atómica y única; anulación solo antes de entregar.
6. Gastos por canal/fecha y reporte con diario, pago, costo, utilidad bruta y resultado después de gastos.
7. Configuración de nombre de empresa. Moneda PEN y America/Lima fijas.
8. Query cache segmentada por tenant y limpiada al cerrar sesión.

## Reglas funcionales y límites

- Dinero en céntimos enteros; cantidades enteras. Máximo unitario S/ 1,000,000, 100,000 unidades por línea y 100 productos por documento. Precio/costo cero y margen negativo son válidos.
- Snapshot por línea: nombre, precio y costo de operación; no recalcular historial con catálogo actual.
- Pedido pendiente no reserva stock ni reconoce ingreso. La entrega valida stock del canal orders, descuenta y contabiliza como una transacción.
- Fecha contable America/Lima; semanas comienzan lunes. Reporte permite rangos inclusivos hasta 367 días.
- Resultado operativo simplificado = ventas − costo de mercadería − gastos. No es contabilidad certificada ni incluye impuestos, cuentas por cobrar o conciliación.
- Idempotencia de ventas, gastos y ajustes; reuso de clave con payload diferente falla. Falta validar concurrencia entre conexiones en Supabase real.
- No borrar operaciones contabilizadas. Devoluciones, notas de crédito, pagos parciales, reservas, roles/invitaciones y suscripciones no están definidos.

## Verificación de esta entrega

- `npm run check`: 28 pruebas aprobadas en 8 archivos, TypeScript, ESLint y formato correctos.
- `npm run build`: aprobado; interfaz de productos sin carga Excel; códigos internos probados con PGlite, no ejecutada en el proyecto Supabase del usuario.

## Verificación de esta migración

- `npm run check`: aprobado; tipos, ESLint, Prettier y pruebas de dominio, sesión temporal, trigger, RLS entre tenants, permisos de lectura directa, idempotencia, venta/entrega, reportes y rollback por stock insuficiente.
- `npm run build`: aprobado para React/Vite. Vite avisa que el bundle inicial es de ~606 kB sin comprimir (~174 kB gzip); queda como optimización posterior si las métricas reales lo justifican.
- Supabase real no fue conectado desde este entorno. La ejecución inicial del SQL y la prueba de registro/login requieren el proyecto real.
- PGlite valida reglas y SQL compatible, pero no sustituye prueba de políticas/funciones en Supabase real ni una prueba de carreras entre procesos.

## Acceso temporal sin login

- Se quitó temporalmente la pantalla de acceso y el botón de salir. Al abrir la app, Supabase crea una sesión anónima y se muestra “Acceso temporal”.
- Habilitar **Authentication → Sign In / Providers → Anonymous Sign-Ins** en el proyecto Supabase.
- Si `schema.sql` ya se ejecutó, aplicar una vez `supabase/temporary_access.sql`; si aún no se ejecutó, instalar el `schema.sql` actualizado.
- RLS y la separación por tenant siguen activas. Esto es solo para desarrollo local; borrar datos del navegador crea otra identidad sin recuperación del tenant anterior. No desplegar esta modalidad públicamente.
- `npm run dev` compila `@saas/domain` antes de iniciar Vite y fuerza la actualización de dependencias para evitar que una salida `dist` anterior mantenga la validación de correo antigua.
- Las sesiones anónimas pueden traer `user.email` como cadena vacía; el perfil de interfaz usa `Acceso temporal` cuando el valor es `null`, vacío o solo espacios.

## Siguiente paso

1. Habilitar Anonymous Sign-Ins y aplicar `schema.sql` o `temporary_access.sql` según el estado de la base.
2. Copiar `.env.example` a `.env`, ejecutar `npm run dev` y probar acceso temporal, productos, venta, entrega, gasto y reporte en ese proyecto.
3. Si la cuenta Supabase existente ya tiene tablas del esquema antiguo, revisar el estado antes de aplicar el SQL; no borrar datos automáticamente.
4. Ejecutar una vez `supabase/product_codes.sql` para convertir códigos Excel existentes y habilitar numeración automática; abrir Productos y comprobar edición modal, alta y stock. Para migrar ventas históricas, resolver primero las incidencias en `docs/excel/LEEME.md`.

Primer acceso: `/acceso`. Flujo recomendado: crear empresa → productos/stock → venta o pedido → gastos → resultados.

## Revisión de alcance con el cliente

Los requisitos operativos del MD están implementados: registro, cálculos, fecha del servidor, reportes, gastos, canales, pagos, dashboard y catálogo. Falta validar un ciclo completo sobre Supabase real con el usuario; las pruebas locales no certifican operación productiva. El histórico no está importado como ventas por datos ambiguos; no hay gestión de cuentas bancarias individuales ni conciliación. Acceso actual anónimo para desarrollo, pendiente autenticación recuperable y roles antes de ofrecerlo como SaaS a clientes.

- Tabla de productos: encabezados y todas las celdas centrados, incluidos identidad del artículo, valores numéricos y botones de gestión.

- Prueba SQL de resultados: utiliza `localDate()` (America/Lima) en lugar de fecha UTC, alineando el gasto y rango del reporte con el día contable.

## Formularios en modales

Nueva venta de menudeo, nuevo pedido, nuevo gasto, detalle, anulación y confirmación de entrega se presentan en modales reutilizables. Alta, edición y stock de productos ya utilizaban modales. Los formularios de venta y detalle usan ancho ampliado; Escape y cierre se bloquean mientras hay una escritura pendiente. Registrar venta desde dashboard abre directamente el modal al navegar a menudeo. Los errores de anulación y entrega permanecen dentro del modal; se conservan cálculos, validaciones, transacciones e idempotencia existentes.

## Adaptación móvil integral

- `src/styles/responsive.css` se carga después del estilo base. Hasta 900 px sustituye el sidebar por botón Menú con navegación en diálogo, nombres completos de las siete secciones y cierre al elegir ruta. Cabecera fija y controles de al menos 44–48 px.
- Hasta 1360 px las seis tablas pasan a fichas adaptables con TODOS los campos y acciones: productos, ventas/pedidos, compositor, detalle, gastos y resumen diario. `data-label` identifica cada campo; encabezados conservados para tecnologías de asistencia y roles explícitos de tabla. No se utiliza ocultación global del desbordamiento para simular la eliminación de barras horizontales.
- Hasta 700 px modales a pantalla completa, formularios de una columna, importes/cantidades táctiles de 16 px, totales apilados, paginación y acciones adaptables. Se respeta safe-area y viewport dinámico; viewport permite zoom y solicita ajuste al teclado en navegadores compatibles.
- Dashboard, filtros de resultados, configuración y acceso tienen rejillas y textos flexibles. Desktop conserva tabla y sidebar.
- Verificación: TypeScript, ESLint, formato, 14 pruebas y build aprobados. No se validó geometría en un navegador real: Playwright estaba disponible sin binarios y la descarga del navegador falló en este entorno. Revisar 320/360/390/430/768/1024 px y orientación horizontal en dispositivos reales, especialmente teclado y foco de los diálogos. No se afirma compatibilidad con todos los navegadores móviles.

## Navegación lateral y productos móviles refinados

- Se reemplazó el menú móvil centrado por `SideDrawer` nativo, anclado a la izquierda, negro, con logo, siete rutas y empresa al pie. El área de secciones tiene scroll vertical independiente para móviles en horizontal; el resto del sitio queda inerte por dialog. Cierra al navegar, Escape, botón y backdrop; restaura foco al disparador. Animación con transform y respeto a movimiento reducido. No se añadieron dependencias.
- Fichas de productos con cabecera de identidad, precio destacado, costo, franja de utilidad/margen, existencias divididas por canal y dos acciones de ancho completo; se conserva el centrado y todos los datos. La vista de escritorio conserva tabla.
- Tests de interacción del drawer en JSDOM cubren Escape, restauración de foco, logo y cierre de backdrop sin cerrar al tocar dentro. Estos tests emulan open/close nativo; no certifican geometría ni foco confinado en un navegador real. Se mantiene pendiente revisión visual física indicada arriba.

- Última verificación del panel lateral: 16 tests aprobados, tipado/lint/formato y compilación correctos.

## Identidad visual REYPRO

Paleta actual amarilla/negra solicitada: acento `#ffd900`, texto oscuro sobre botones amarillos, menús negros con selección amarilla, dashboard negro con importes amarillos, superficies neutras y detalles amarillo suave. Texto de enlaces sobre blanco usa tono oscuro `#665500` para legibilidad; foco `#806b00`. Conserva rojo para errores. Tokens centralizados en `styles/tokens.css`, incluidos hover, tinta y fondos suaves; se actualizaron colores verdes fijos en estilos base y móviles. Logo real permanece en `public/logo.png` del usuario.

## Ajuste de paleta sobria (vigente)

El usuario rechazó el amarillo saturado. Acento actual oro/mostaza desaturado `#b6a16b`, hover `#a9925a`, superficies arena `#f3f0e7` y texto oscuro `#6b5a30`. Selección del sidebar y drawer con fondo oscuro `#29261e`, borde tenue y texto oro pálido `#decfa5`, en lugar de bloques amarillos sólidos. Logo original conserva su color; botones usan acento apagado con texto negro. Reemplaza la decisión anterior #ffd900.

## Modal de ventas con inventario agrupado

- `CatalogInventory` consulta productos activos mediante filtro servidor antes de paginar; búsqueda por nombre/código, columnas artículo/precio/stock/agregar y selección indicada por cantidad. Se retiró el selector de tarjetas sueltas. No se descarga el catálogo completo.
- `SaleComposer` utiliza paneles inventario/detalle, líneas editables con controles +/−, precio/costo en céntimos y desglose de venta/costo/utilidad. En móvil paneles apilados sin scroll horizontal y botón para saltar al detalle. La búsqueda no envía el formulario con Enter.
- Bloqueo referencial de menudeo si cantidad supera stock consultado, también en submit; límite 100 productos y 100,000 unidades. Stock se valida definitivamente en la transacción del servidor. Pedidos siguen permitiendo programar sin stock y se validan al entregar. Se preservan UUID de idempotencia, cliente, pago, fecha prevista, snapshots y márgenes negativos.
- Pruebas agregadas: repetir producto acumula una línea, bloqueo por stock en menudeo, edición de precio y payload; pedidos sin stock mantienen cliente y fecha. No se requiere migración SQL.

- Verificación del compositor renovado: 19 tests aprobados y compilación correcta; incluye pruebas de operación con stock y pedidos sin stock. Revisión visual real sigue pendiente.

## Alto fijo del compositor y paginación

- Modal comercial `fitted`: alto calculado desde visualViewport/viewport y espacio interior repartido con flex; sin regiones de scroll internas. Inventario consulta un pageSize variable medido con ResizeObserver; cada página cabe en el área de resultados. No se ocultan registros: se acceden mediante paginación.
- Detalle muestra una línea por página; conserva en estado todas las cantidades y precios editados. Resumen de toda la operación y botones permanecen visibles.
- A menos de 1000 px de ancho o 740 px de alto, Datos/Inventario/Detalle se presentan mediante botones de sección. Se conservan inputs de datos y la validación Zod; submit abre sección/artículo con datos inválidos. Se agrega prueba de persistencia entre páginas de detalle.
- Mantiene pendiente revisión geométrica real en navegador, especialmente teclado abierto y pantallas de poca altura: no se garantiza que todos los campos quepan simultáneamente en cualquier viewport. El cambio organiza el contenido por páginas/secciones sin borrar datos.

- Última validación del alto fijo: 20 tests aprobados, tipo/lint/formato y compilación correctos.

## Dos secciones y scroll móvil (decisión vigente)

El usuario autorizó scroll vertical en móvil. Se retiró la sección Datos: solo Inventario/Detalle; cliente, pago y fecha prevista ahora pertenecen a Detalle. El cuerpo del modal móvil tiene una única región de scroll vertical y las pestañas permanecen accesibles; cambiar sección vuelve al inicio conservando los valores. Desktop mantiene altura fija y paginación.

Se retiró ResizeObserver del inventario: la capacidad depende solo de cambios reales del viewport, no del contenido cargado, evitando ciclos de medición/carga. En móvil se muestran 10 registros por página con scroll; en desktop se limita la página según alto de pantalla. React Query conserva filas previas durante cambios dentro del mismo tenant y el mensaje Consultando solo se muestra sin datos; actualización de fondo indica Actualizando sin vaciar el panel. El supuesto ciclo era una causa posible identificada por revisión de código, no reproducida en navegador real.

Se agrega prueba de dos únicas secciones y persistencia de cliente al alternarlas. La validación de cliente obligatorio ahora abre Detalle. Revisión visual real pendiente.

- Verificación de las dos secciones y carga estable: 21 pruebas aprobadas, TypeScript/lint/formato y compilación correctos.

## Flujo corregido según aclaración del usuario (vigente)

El modal usa exactamente dos pestañas en TODOS los tamaños. Venta contiene cliente, método de pago/transferencia, entrega prevista si es pedido y debajo búsqueda del inventario. No consulta ni muestra productos si el buscador está vacío; al escribir muestra coincidencias seleccionables. Detalle contiene todas las líneas agregadas y cantidades/precios/costos editables, sin paginación de una línea. Cambiar pestaña conserva inputs y estado. Cliente obligatorio faltante vuelve a Venta; línea inválida abre Detalle.

El cuerpo central tiene scroll vertical independiente en un modal de alto fijo. Pestañas y resumen con Cancelar/Confirmar quedan fuera de ese scroll y por tanto fijos en ambos tamaños. Se simplificó `sale-checkout.css` eliminando reglas superpuestas de los diseños anteriores. Búsqueda con query `enabled` explícito y paginación fija de 10 coincidencias, sin observers ni cambios de capacidad.

Pruebas actualizadas al flujo real: búsqueda vacía oculta opciones, escribir/limpiar, todos los artículos visibles en Detalle, preservación entre pestañas y validación del cliente en primera pestaña. Continúa pendiente validación visual real en dispositivos.

- Verificación del flujo aclarado: 22 tests aprobados, TypeScript/lint/formato y compilación correctos.

## Área útil y búsqueda sin encabezado redundante

Se retiró el footer completo de la aplicación (nombre y React/TypeScript). Main ocupa el área disponible bajo la cabecera. En Venta se eliminó la cabecera Catálogo de menudeo/pedidos, conservando cliente/pago, buscador y paginación. El tamaño de página se calcula a partir del alto del stage y del formulario, reservando buscador/paginador; nunca mide filas cargadas, para evitar ciclos de consulta. ResizeObserver observa solo contenedores estables y deja de medir al cambiar a Detalle. No busca productos hasta escribir. Buscador/paginador quedan accesibles; en pantallas de muy poca altura se permite scroll vertical. Pendiente verificación geométrica real.

- Listados de menudeo/pedidos/productos se extienden hasta el área inferior disponible sin footer técnico; paginación al pie del panel. Última verificación: 22 pruebas y compilación correctas.

## Modal avanzado de productos

Alta/edición rediseñadas con identificación, precios y existencias en secciones. Vista previa reactiva de utilidad unitaria, margen sobre venta, unidades asignadas y valor de stock al costo. Calcula con parseMoney/céntimos; precio cero deja margen sin base y costo mayor al precio muestra pérdida sin impedir su registro. Código automático se presenta como información; no agrega campos ajenos al esquema. Edición conserva disponibilidad y no escribe existencias: ajustes desde la acción Stock.

Modal de alto fijo con cuerpo desplazable y botones fijos. Desktop con vista previa lateral; móvil en una columna. Se conserva paleta mostaza apagada. Pruebas nuevas de payload de alta, stock independiente, margen/pérdida y edición sin alterar código/stock. Pendiente revisión visual real.

- Última validación del editor de productos: 25 pruebas aprobadas y compilación correcta.

## Simplificación solicitada del editor de producto

Se retiró completa la vista previa lateral (nombre/código, utilidad, margen, unidades y valoración) y el bloque visible de código interno/asignación automática. El formulario ocupa una columna de secciones en un modal de ancho ajustado. Código automático sigue en payload/servidor; edición conserva el código existente. Se mantiene aviso local de pérdida cuando precio < costo, validaciones y stock separado. Estilos y pruebas que dependían de la vista previa fueron retirados/actualizados.

## Vista general rediseñada y acento ámbar (vigente)

Acento actual `#f0b323` (ámbar vivo), hover `#dda013`, fondos crema `#fff4d6` y tinta oscura `#735000`. Se mantiene menú negro con selección oscura y texto dorado; sustituye mostaza apagado rechazado por el usuario.

Dashboard rediseñado: cinco resultados de hoy (incluye resultado neto), bloque semanal con desglose completo y acceso a reportes, actividad diaria con barras de ventas reales y etiquetas monetarias, distribución de ventas por método de pago y accesos a nueva venta/pedido/productos/gastos. No se inventan porcentajes de crecimiento, comparaciones ni objetivos. Días sin registros muestran cero solo cuando existe reporte cargado; carga/error muestra placeholders. Fechas y semana de Lima se conservan. Barras decorativas aria-hidden con importes textuales accesibles. Responsive de una a varias columnas sin scroll horizontal.

Pruebas agregadas: importes diarios/semanales y pagos, rutas que abren modales, estados vacíos y resultado negativo. Revisión visual real sigue pendiente.

- Verificación del dashboard rediseñado: 28 pruebas y compilación correctas.

## Analítica de vista general (sustituye bloque semanal anterior)

Se eliminó el bloque oscuro de resultado semanal, su desglose y enlace redundante. Se incorporó gráfico SVG de columnas agrupadas: ventas frente a mercadería y gastos apilados, escala monetaria, leyenda y selección de fecha con detalle accesible. Sin dependencias nuevas ni datos simulados; consulta semanal existente. Se conserva la distribución por pagos y resultados diarios.

Indicadores semanales: ticket promedio redondeado a céntimos, margen bruto sobre ventas, cobertura de gastos (utilidad bruta/gastos) y utilidad bruta semanal. Divisores cero muestran guion; sin gastos se informa explícitamente, sin inferir cobertura infinita. Componentes en dashboard/components/BusinessCharts.tsx. Layout responsive sin contenedores de ancho fijo. Pendiente revisión visual real en dispositivos; continuar desde estos componentes para futuras mejoras del dashboard.

- Validación vigente: 28 pruebas aprobadas, TypeScript/lint/formato y build correctos. Incluye selección de fecha, indicadores, divisores cero y resultado negativo.

## Centro de operaciones compacto (vigente)

Sustituye el dashboard anterior rechazado por tamaño y jerarquía. Cabecera Centro de operaciones con actualizar datos y nueva venta; accesos a pedido, productos/inventario, gastos y reportes. Cuatro indicadores de hoy: ventas, utilidad bruta (costo de mercadería como dato secundario), gastos y resultado neto.

Dos columnas desktop, una móvil. Ventas semanales con barras de altura fija (158px desktop/140px móvil), una sola serie y selección de día con importe. Sin SVG de tamaño proporcional al ancho ni bloque repetido de cinco cifras. Estado vacío compacto con acción; no dibuja actividad ficticia. Ticket/margen/utilidad semanal integrados al pie del gráfico. Distribución por pagos con barras horizontales y porcentajes; desglose semanal mercadería/gastos/resultado y mensaje de cobertura real.

Nueva consulta de lectura dashboard.api.pendingOrders: solo pedidos pendientes, total exacto independiente del límite de cinco, orden por fecha programada (sin fecha al final), creación e id. Usa cliente Supabase autenticado y RLS existentes. Hook con clave por tenant; mutaciones de ventas ya invalidan todo el tenant. La lista muestra atrasados/hoy/pendientes y abre SaleDetail real en modal; no cambia estados ni contabiliza. No requiere migración. No se presentan alertas de stock calculadas desde un subconjunto del catálogo.

Siguiente punto: revisión visual en navegador/dispositivos; este entorno no tiene navegador instalado. Mantener src/styles/overview.css como única hoja del centro y componentes BusinessCharts.tsx. Se conserva paleta ámbar y sidebar.

- Validación: 30 pruebas aprobadas; TypeScript, lint, formato y compilación correctos. Se probaron selección de día, ticket/margen, pérdidas, estados vacíos/carga/error y apertura/cierre del detalle de pedido. Sin validación visual real ni prueba de la consulta nueva contra Supabase remoto.

## Modal de venta completo en PC y capacidad móvil

Desde 960px se ocultan las pestañas y se muestran simultáneamente datos (ancho completo), búsqueda de inventario y detalle de artículos. Modal ancho hasta 1560px, ajustado a viewport. Cuerpo con áreas de resultados/detalle desplazables y footer fijo. Bajo 960px se mantienen Venta/Detalle; inputs y borrador se conservan al cambiar de pestaña o cruzar el breakpoint mediante useMediaQuery/useSyncExternalStore.

Móvil: datos compactados en dos columnas (fecha de pedido en fila completa), márgenes reducidos, filas de producto de 72px con nombre hasta dos líneas y seleccionado junto al código. Capacidad de página medida desde el viewport real de resultados, con ResizeObserver/visualViewport y paginador reservado durante carga; no depende de cantidad de filas cargadas. Altura muy reducida/teclado permite desplazamiento y una coincidencia por página. Buscador permanece operativo, se sigue buscando solo al escribir. No cambian validaciones, precios históricos, idempotencia, stock ni Supabase.

Punto de continuación: SaleComposer.tsx, CatalogInventory.tsx y sale-checkout.css. Pendiente verificación geométrica en dispositivos reales; pruebas DOM no equivalen a captura de navegador.

- Validado: 32 pruebas, TypeScript/lint/formato y build correctos. Nuevas pruebas de PC sin pestañas, cambio PC/móvil conservando borrador y capacidad de consulta según alto del viewport.

## Simplificación del historial de menudeo

Se retiraron Actualizar y Detalle únicamente del historial de menudeo, incluida la columna Acciones completa para no dejar celdas vacías. Pedidos conserva sus controles de consulta, entrega y anulación. La invalidación automática por tenant después de registrar una operación sigue vigente. Archivo modificado: src/features/transactions/components/SalesWorkspace.tsx.

Actualización de entregas: copiar src encima no elimina archivos retirados; ExcelCatalog.tsx es obsoleto y debe eliminarse si quedó en una instalación anterior. No restaurar importCatalog para resolver ese error de compilación.

- Validación de simplificación: 32 pruebas, TypeScript/lint/formato y compilación correctos.

## Alineación de artículo y código interno

Encabezado de Artículo / Código interno permanece centrado. Contenido de la primera columna y grupo icono/nombre/código alineados a la izquierda, también en tarjeta móvil. Cambio localizado al final de src/styles/responsive.css.

- Validación: 32 pruebas y compilación correctas; ajuste de CSS sin cambios de lógica.

## Recarga de rutas en despliegue

Se incorporó vercel.json en raíz junto a package.json con rewrite /(.*) a /index.html para React Router (BrowserRouter). Antes solo existía public/_redirects para Netlify. El síntoma reportado es 404 al recargar una sección; los logs previos apuntan a Vercel, sin URL de despliegue confirmada. Requiere subir vercel.json y desplegar otra vez; no basta reemplazar src. Falta comprobar recarga de /productos y /menudeo en el hosting real.

- Validación local: 32 pruebas y build correctos. Configuración conforme al fallback SPA documentado por Vercel; sin despliegue remoto ejecutado.

## Cuenta compartida solicitada (reemplaza acceso temporal)

Usuario pidió una cuenta única admin@sistema.com / admin123. Se restauró /acceso como login real y ProtectedLayout redirige cuando no hay sesión permanente. authApi.session ya no llama signInAnonymously: sesiones anónimas existentes devuelven null sin borrarse; credenciales correctas sustituyen la sesión. Login valida contraseña no vacía, Supabase verifica credenciales; registro mantiene mínimo 12 aunque la UI ya no ofrece registro. No se incrusta contraseña ni clave administrativa en el bundle. Badge de cabecera indica sesión iniciada.

Nuevo npm run setup:admin (scripts/setup-admin.mjs): solicita clave administrativa en terminal con entrada oculta, lista empresas y conteos exactos, pide elección explícita de empresa existente, crea/confirma usuario usando API Auth Admin y enlaza public.users al tenant seleccionado. En reintentos busca cuenta existente y actualiza contraseña solicitada. Bloquea traslado de un admin con operaciones propias; claves compuestas siguen protegiendo integridad. Conserva tenants/datos anónimos, no fusiona ni elimina registros. Procedimiento no es transacción global; error puede dejar cuenta creada y reintento completa. Política de contraseña de Supabase puede rechazar admin123; no se desactiva.

IMPORTANTE: cuenta NO creada ni vinculada remotamente por el asistente: solo hay clave publicable disponible. Usuario debe ejecutar comando una vez con secret/service_role, sin ponerla en VITE_ ni enviarla al chat. docs/ACCESO_ADMIN.md contiene instrucciones. Ambos dominios deben usar el mismo proyecto Supabase. Punto siguiente: ejecutar setup local, comprobar login en ambos dominios y recuperación de productos. La URL compartida por sí sola no comparte sesión/empresa.

- Validación: 37 pruebas y compilación correctas; sintaxis del script validada. Pruebas cubren ausencia de alta anónima, rechazo de sesión anónima, perfil de empresa desde Supabase, contraseña de 8 caracteres en login y credenciales incorrectas sin fallback. Aprovisionamiento remoto pendiente por falta de acceso administrativo.

## Cuenta confirmada por el usuario

El usuario ejecutó setup:admin y compartió éxito: admin@sistema.com quedó asociado a 35af1991-2d1c-4099-b1c8-d5b1bff04186 (Control Comercial, 337 productos y 1 operación al configurar). Sustituye el pendiente de aprovisionamiento anterior. No se requiere repetir setup. No se ha comprobado el login remoto desde este entorno.

## Códigos de pedidos y distribución de historiales

Nuevo order_code persistido en sales, automático PED-000001 mediante secuencia global (puede tener saltos). Único, inmutable y solo para canal orders. Trigger SECURITY DEFINER con search_path vacío; no permite elegir el código desde el navegador. Migración supabase/order_codes.sql asigna códigos a pedidos existentes ordenando por creación/id, mantiene IDs/estado/stock/importes, puede reejecutarse y preserva permisos. El schema para instalaciones nuevas incluye la migración al final; NO ejecutar schema completo sobre base existente.

Antes de desplegar frontend ejecutar order_codes.sql en SQL Editor. Actualizar src y packages (contrato orderCode y consulta). sale_detail RPC devuelve también orderCode. Código aparece en primera columna del historial y título del detalle. Entrega se muestra dd/mm/aaaa. Actualizar retirado de pedidos; ambos canales usan invalidación automática ya existente. Tablas con colgroup: más ancho para identidad/acciones y tres columnas de dinero iguales. En móvil se mantienen fichas, acciones completas y sin columna vacía en menudeo.

Pendiente prueba visual y migración en Supabase real. Continuar en SalesWorkspace.tsx, transactions.api.ts y supabase/order_codes.sql.

- Validación: 38 pruebas y build correctos; prueba SQL de código automático, inmutable, reintento, entrega, migración reejecutable y backfill conservando stock. Sin prueba concurrente en Supabase remoto.

## Filtros de inventario y localización después de editar (26/10/2026)

Búsqueda seleccionable por nombre/código/ambos, stock positivo o cero por canal, orden nombre/código/precio y tamaños 10/25/50. Consultas filtran en Supabase antes de paginar y mantienen total exacto; stock usa relación inventory!inner y canal, sin filtrar un subconjunto cargado. Sigue obteniendo ambos stocks para mostrar la fila. RLS existente, sin migración nueva.

El nombre modifica la posición alfabética y puede dejar de coincidir con una búsqueda previa. ProductEditor notifica el ID guardado tras éxito; ProductsPage limpia filtros previos y muestra ese ID con mensaje y acción Ver todo el inventario. Conserva código, historial y cantidades. Cancelar conserva búsqueda/página. Crear también localiza el registro nuevo. Queries incorporan filtros en su clave por tenant y se invalidan tras mutación.

README corregido: login real, cuenta existente, arranque desde otra computadora con npm ci; no repetir alta/tenant ni activar acceso anónimo. ZIP incluye .env publicable y migración previa de pedidos; logo original no disponible y debe copiarse a public/logo.png. Antes del despliegue aplicar order_codes.sql si falta; no reinstalar schema completo.

Punto de continuación: ProductsPage, ProductEditor, useProducts y products.api. Pendiente comprobar filtros contra Supabase remoto y geometría en dispositivos reales; este entorno no realizó esas comprobaciones.

- Validación: 40 pruebas aprobadas en 10 archivos; typecheck, ESLint, Prettier y build correctos. Regresión de renombrado con filtro y página previos, regreso al catálogo y cancelación conservando filtros.
