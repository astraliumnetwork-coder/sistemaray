# Arquitectura · Supabase directo

## Flujo

React por módulos → hooks React Query → repositorios del módulo → Supabase JS → PostgREST/RPC → PostgreSQL. `packages/domain` conserva esquemas Zod y reglas de dinero/fechas.

## Identidad y tenants

Supabase Auth gestiona credenciales y sesión. Un trigger crea tenant y perfil al registrar la cuenta. Las tablas de negocio incluyen `tenant_id`; `current_tenant_id()` lo deriva del perfil asociado a `auth.uid()`. RLS aplica el aislamiento en las lecturas directas. Las escrituras usan RPC limitados que derivan tenant y actor y filtran cada operación por el tenant autenticado. El navegador usa solo la publishable key; nunca `service_role`.

## Transacciones e idempotencia

Lecturas simples usan PostgREST con paginación y RLS. Crear/editar producto, ajustar stock, crear venta, entregar/cancelar pedido y guardar gasto usan RPC SQL; el navegador solo tiene permisos de lectura directa. Los RPC de escritura usan `SECURITY DEFINER` con `search_path` vacío, no aceptan `tenant_id` y lo derivan de `auth.uid()` antes de filtrar cada escritura por ese tenant. No exponer RPC a `anon`. Stock, movimientos y cabeceras se actualizan en una única transacción. Claves únicas más advisory locks evitan duplicados por reintentos; la misma clave con payload distinto falla.

La salida de menudeo y la entrega bloquean/actualizan existencias dentro del RPC. Pedidos pendientes no reservan stock. El orden estable por producto reduce deadlocks. Un error en una línea revierte toda la operación.

## Datos y reportes

Dinero en céntimos `bigint`; importes no se suman en JavaScript con coma flotante. Los snapshots de cada venta conservan producto/precio/costo históricos. Reportes filtran rangos semiabiertos por timestamp convertido a America/Lima, agrupan en SQL y limitan el intervalo a 367 días. Índices cubren tenant, canal, fecha e historial.

## Rendimiento y mantenimiento

- React Query segmenta caché por tenant y borra caché al cerrar sesión.
- Listas paginadas en base de datos; no se descargan historiales completos.
- No se han ejecutado pruebas de carga ni EXPLAIN con datos de producción.
- `supabase/schema.sql` es la instalación inicial. Si ya se aplicó, no vuelvas a ejecutar un archivo que contenga cambios destructivos; los cambios futuros deben ser migraciones incrementales.
