// @vitest-environment node
import { describe, expect, it } from 'vitest';
import {
  calculateLine,
  parseMoney,
  dateSchema,
  localDate,
  saleInput,
  sessionSchema,
} from '@saas/domain';

describe('reglas financieras', () => {
  it('evita errores binarios al convertir precios y multiplicar', () => {
    expect(parseMoney('0.10')).toBe(10);
    expect(calculateLine(3, parseMoney('0.10'), parseMoney('0.03'))).toEqual({
      salesCents: 30,
      costTotalCents: 9,
      grossCents: 21,
    });
  });
  it('permite pérdida y costo cero, rechaza fracciones de centavo y cantidades fraccionarias', () => {
    expect(calculateLine(2, 10, 20).grossCents).toBe(-20);
    expect(calculateLine(1, 10, 0).grossCents).toBe(10);
    expect(() => parseMoney('1.001')).toThrow();
    expect(() => parseMoney('1e3')).toThrow();
    expect(() => calculateLine(0.5, 10, 5)).toThrow();
  });
  it('respeta la medianoche de Lima y valida días reales', () => {
    expect(localDate(new Date('2026-10-21T04:59:59Z'))).toBe('2026-10-20');
    expect(localDate(new Date('2026-10-21T05:00:00Z'))).toBe('2026-10-21');
    expect(dateSchema.safeParse('2026-02-30').success).toBe(false);
  });
  it('rechaza un mismo producto repetido en el documento', () => {
    const item = {
      productId: 'c34a7896-9db6-458c-8bc6-2cd7ba71509d',
      quantity: 1,
      priceCents: 100,
      costCents: 50,
    };
    expect(
      saleInput.safeParse({ channel: 'retail', payment: 'cash', items: [item, item] }).success,
    ).toBe(false);
  });
  it('acepta la identidad temporal sin correo electrónico', () => {
    expect(
      sessionSchema.parse({
        userId: 'c34a7896-9db6-458c-8bc6-2cd7ba71509d',
        tenantId: 'c34a7896-9db6-458c-8bc6-2cd7ba71509d',
        email: 'Acceso temporal',
        organizationName: 'Control Comercial',
      }).email,
    ).toBe('Acceso temporal');
  });
});
